#####################################
#         Another Text RPG          #
#         By: Rush Deeter           #
# In Collaboration With: Kathy Orta #



"""


This file lays out the ability for
the player to move throught eh world.
The code included is:

Functions:
    - display_location()
    - player_movement()
    - movement_handler()


"""



from WorldMapFile import *
from Utility import enter,text_display
from Adventures.Questing import quest_locator
from AcceptableLists import directions,mistakes



def display_location(player, player_location, map_type):
    
    """

        Displays the player's current location
        on the World Map.

    """
    
    print('\n\n' + ('=' * (6 + len(map_type[player_location][TILE_NAME]))))
    print('   ' + map_type[player_location][TILE_NAME])
    #if map_type[player_location][QUEST] == 'was quest':
    #    print(' - ' + map_type[player_location][WAS_QUEST_TEXT])


def player_movement(direction, player, player_action, player_location, map_type):
    
    """

        Prompts the player for a directional input and 
        calls the 'movement handler' to actually move
        the player on the World Map.

    """

    valid_directions = directions+mistakes
    if direction not in valid_directions:
        print("Where would you like to " + player_action + "?")
        while direction not in valid_directions:
            direction = input(" > ").lower()

    if direction in ['up','north']:
        destination = map_type[player_location][UP]
        movement_handler(destination, direction, player, player_action, map_type)
    elif direction in ['down','south']:
        destination = map_type[player_location][DOWN]
        movement_handler(destination, direction, player, player_action, map_type)
    elif direction in ['left','west']:
        destination = map_type[player_location][LEFT]
        movement_handler(destination, direction, player, player_action, map_type)
    elif direction in ['right','east']:
        destination = map_type[player_location][RIGHT]
        movement_handler(destination, direction, player, player_action, map_type)

    elif direction in ['northwest']:
        destination = map_type[player_location][LEFT]
        destination2 = map_type[destination][UP]
        movement_handler(destination2, direction, player, player_action, map_type)  
    elif direction in ['northeast']:
        destination = map_type[player_location][RIGHT]
        destination2 = map_type[destination][UP]
        movement_handler(destination2, direction, player, player_action, map_type)
    elif direction in ['southeast']:
        destination = map_type[player_location][RIGHT]
        destination2 = map_type[destination][DOWN]
        movement_handler(destination2, direction, player, player_action, map_type)
    elif direction in ['southwest']:
        destination = map_type[player_location][LEFT]
        destination2 = map_type[destination][DOWN]
        movement_handler(destination2, direction, player, player_action, map_type)

    elif direction in mistakes:
        pass


def movement_handler(destination, direction, player, player_action, map_type):
    
    """

        Determine's if the player is able to
        move in the selected direction and
        then moves the player or returns them
        to the 'prompt' function.

    """ 

    """
    if destination[TILE_NAME] in ['Wall']:                                                                       
        text_display(destination,.02)
    elif destination in map_type: 
        player_location = destination
        movement_description = "You " + player_action + " " + direction + "."
        text_display(movement_description,.02)
        display_location(player)
        if map_type[player_location][TILE_NAME] not in player.places_visited:
            player.places_visited.append(map_type[player_location][TILE_NAME])
            print(player.places_visited)
    """


    if map_type[destination][TILE_NAME] in ['Wall', 'River']:    
        if map_type[destination][TILE_NAME] == 'Wall':
            text_display("There's a wall there.",.02)
        elif map_type[destination][TILE_NAME] == 'River':
            text_display("This river is uncrossable.",.02)
    elif destination in map_type: 
        if map_type == world_map:
            player.location = destination
            text_display("You " + player_action + " " + direction + ".",.02)
            display_location(player, player.location, map_type)
            if map_type[player.location][TILE_NAME] not in player.places_visited:
                player.places_visited.append(map_type[player.location][TILE_NAME])
        else: 
            player.quest_location = destination
            text_display("You " + player_action + " " + direction + ".",.02)
            display_location(player, player.quest_location, map_type)
            if map_type[player.quest_location][TILE_NAME] not in player.places_visited:
                player.places_visited.append(map_type[player.quest_location][TILE_NAME])
