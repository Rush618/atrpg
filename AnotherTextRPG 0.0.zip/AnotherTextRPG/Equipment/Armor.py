#####################################
#         Another Text RPG          #
#         By: Rush Deeter           #
# In Collaboration With: Kathy Orta #
#   Started work on Sept 9, 2020    #



"""


This file contains the information for
the weapons in the game.

Classes:
    - Adjective
    - Material
    - Armor_Type
    - Armor


"""


import random
from statistics import mean



# Inside monster class a function is defined which allows for random weapon & armor generation based on a given list which is one of the attributes

class Adjective:

    """

        Lays out the setup for adjectives which are used to 
        describe weapons. The attributes are the name of the
        adjective, the multipliers that effect the minimum
        and maximum damage for the weapon, and the multiplier
        which effects how much the weapon costs.

    """

    def __init__(self, name, def_multiplier, value_multiplier):
        self.name = name
        self.def_multiplier = def_multiplier
        self.value_multiplier = value_multiplier


horrible = Adjective('horrible ', .4, .15)
bad = Adjective('bad ', .5, .25)
shoddy = Adjective('shoddy ', .6, .5)
dull = Adjective('dull ', .8, .75)
standard = Adjective('', 1, 1)
fine = Adjective('fine ', 1.1, 1.25)
exquisite = Adjective('exquisite ', 1.3, 1.5)
magnificent = Adjective('magnificent ', 1.5, 2)
godly = Adjective('godly ', 2, 5)


class Material:

    """

        Initializes the name of the material for a weapon,
        the base minimum and maximum that material possesses,
        and how much that material is worth.

    """

    def __init__(self, name, base_armor, str_required, base_value):
        self.name = name
        self.base_armor = base_armor
        self.str_required = str_required
        self.base_value = base_value


cloth = Material('cloth ',1,1,1)

iron = Material('iron ', 2, 5, 18)
silver = Material('silver ', 4, 8, 25)
titanium = Material('titanium ', 7, 12, 35)
adamantine = Material('adamantine ', 11, 17, 48)
mythril = Material('mythril ', 0, 0, 65)


class Armor_Type:

    """

       Sets up the different types of weapons including their
       name, minimum damage multiplier, maximum damage multiplier,
       and value multiplier, which effects the monetary value
       of a weapon.

    """

    def __init__(self, name, def_multiplier, str_req_multiplier, value_multiplier):
        self.name = name
        self.def_multiplier = def_multiplier
        self.str_req_multiplier = str_req_multiplier
        self.value_multiplier = value_multiplier


clothes = Armor_Type('clothes',1,1,0)

just_armor = Armor_Type('armor',1,1,1)

#chain = Weapon_Type('chain', 1.1, .9, .8)
#scale = Armor_Type('scale armor', 1, 1, 1)
#plate = Weapon_Type('plate', .75, 1.15, 1.1)

#battleaxe = Weapon_Type('battleaxe', .65, 1.2, 1)


class Armor:

    """
    
        Uses the information from the Adjective, Material,
        and Weapon_Type classes to determine the weapon's 
        name, minimum damage, maximum damage, and value.

    """

    def __init__(self, adjective, material, armor_type):
        self.adjective = adjective
        self.material = material
        self.weapon_type = armor_type
        self.name = adjective.name + material.name + armor_type.name
        self.defense =  round(mean([adjective.def_multiplier, armor_type.def_multiplier]) * material.base_armor)
        #self.strength_required = round(armor_type.str_req_multiplier * material.str_required)
        self.value = int(((adjective.value_multiplier + armor_type.value_multiplier) / 2) * material.base_value)

        self.abbrev = ''
        name_string = self.name.split()
        for word in name_string:
            self.abbrev += word[0]



def armor_dict(list_of_armor):

    """

        Creates a dictionary of armor from a 
        given list of armors. This is used later 
        when armor needs to be displayed for
        shokeepers and potentially other things like
        monster loot tables.

    """

    DEFENSE = "Defense"
    VALUE = "Value"

    armors = {}

    for armor in list_of_armor:
        armors[armor.name] = {
            DEFENSE: armor.defense,
            VALUE: armor.value
        }
    
    return armors


common_clothes = Armor(standard,cloth,clothes)


###############      Iron      ###############
#standard_iron_scale = Armor(standard, iron, scale)
standard_iron_armor = Armor(standard,iron,just_armor)



###############      Axes      ###############




#############       Hammers      #############





#############      Polearms      #############




#############       Special      #############








#########   Special Enemy "Armors"   #########
fungus = Material('fungus ',1,1,1)
stalk = Armor_Type('stalk',1,1,5)

fungus_stalk = Armor(standard, fungus, stalk)




