#####################################
#         Another Text RPG          #
#         By: Rush Deeter           #
# In Collaboration With: Kathy Orta #
#   Started work on Sept 9, 2020    #



"""


This file contains the information for
the potions in the game.

Classes:


"""


class RestorationPotion:
    def __init__(self, name, abbrev, restores, restore_amount, value):

        self.name = name
        self.abbrev = abbrev

        self.restores = restores
        self.restore_amount = restore_amount

        self.value = value

wimpy_healing_potion = RestorationPotion('wimpy healing potion', 'whp', 'Health', 5, 20)

wimpy_mana_potion = RestorationPotion('wimpy mana potion', 'wmp', 'Mana', 10, 30)


def restoration_potions_dict(list_of_potions):

    """

        Creates a dictionary of spells from a 
        given list of spells. 

    """
   
    RESTORES = "Restores"
    AMOUNT = "Amount"
    VALUE = "\nValue"

    potions = {}

    for potion in list_of_potions:
        potions[potion.name] = {
            RESTORES: potion.restores,
            AMOUNT: potion.restore_amount,
            VALUE: potion.value

        }
    
    return potions