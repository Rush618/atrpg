#####################################
#         Another Text RPG          #
#         By: Rush Deeter           #
# In Collaboration With: Kathy Orta #
#   Started work on Sept 9, 2020    #



"""


This file contains the information for
the spells in the game.

Classes:
    - DamageSpell
    - HealingSpell

"""



class DamageSpell:
    def __init__(self, name, abbrev, max_dmg, mp_cost):

        self.name = name
        self.abbrev = abbrev

        #self.effect = effect

        self.max_dmg = max_dmg

        self.mp_cost  = mp_cost

     

fireslap = DamageSpell("fireslap", "fs", 9, 5)



def damage_spells_dict(list_of_spells):

    """

        Creates a dictionary of spells from a 
        given list of spells. 

    """
   
    MAX_DAMAGE = "Max Damage"
    MANA_COST = "Mana Cost"

    spells = {}

    for spell in list_of_spells:
        spells[spell.name] = {
            MAX_DAMAGE: spell.max_dmg,
            MANA_COST: spell.mp_cost

        }
    
    return spells



class HealingSpell:
    def __init__(self, name, abbrev, heal_amount, mp_cost):

        self.name = name
        self.abbrev = abbrev

        #self.effect = effect

        self.heal_amount = heal_amount

        self.mp_cost  = mp_cost

        

wimpyheal = HealingSpell("wimpy heal", "wh", 4, 10)



def healing_spells_dict(list_of_spells):

    """

        Creates a dictionary of spells from a
        given list of spells. 

    """
   
    HEALS = "Heals"
    MANA_COST = "Mana Cost"

    spells = {}

    for spell in list_of_spells:
        spells[spell.name] = {
            HEALS: spell.heal_amount,
            MANA_COST: spell.mp_cost

        }
    
    return spells