#####################################
#         Another Text RPG          #
#         By: Rush Deeter           #
# In Collaboration With: Kathy Orta #



"""

This file is meant for functions that are used 
in most other files for this game. Currently,
the functions on this page include:

Functions:
    - enter
    - text_display


"""



import sys
import time 
from AcceptableLists import accept,decline



def enter():
    
    """

        Prompts the player to press 'enter'.
        Mostly used to help the storytelling pace.

    """
    
    print()
    input("(enter)")
    print()


def text_display(text,rate):
    
    """

        Prints the specified string at the 
        specified rate one cahracter at
        a time.

    """
    
    for character in text:
        sys.stdout.write(character)
        sys.stdout.flush()
        time.sleep(rate)


def quit_game(function_to_call,*args):

    """

        Asks the player if they want to quit
        the game and exits if so.

    """

    answer = ''
    options = accept+decline
    print("Are you sure you want to quit the game?")
    while answer not in options:
        answer = input(" > ")
    if answer in accept:
        exit()
    else: function_to_call(*args)

    
def stat_display(player):
    print()
    print()
    print("+=============+")
    print("     STATS     ")
    print(                 )
    print("   LVL  %d" % player.lvl)
    print("   EXP  %d" % player.xp)
    print(                 )
    print("   HP   %d/%d" % (player.hp,player.maxhp))
    print("   MP   %d/%d" % (player.mp,player.maxmp))
    print(                 )
    print("   DEX  %d" % player.DEX)
    print("   INT  %d" % player.INT)
    print("   STR  %d" % player.STR)
    print("+=============+")
    print()
    print()


def losscon(player,opponent):
    if player.cur_health == 0:   
        print()
        print()
        print()
        print()
        print()
        print("                _____")
        print("               |     |")
        print("               |     |")
        print("        ______/       \______")
        print("       |         RIP         |")
        print("               %s " % player.name)
        print("       +------         ------+" )
        print("              \       /")
        print("               |     |")   
        print("               |     |")
        print("               |     |")
        print("          ____/       \____")
        print("         |    SLAIN  BY    |")
        print("              %s            " % opponent.name)
        print("         +-----------------+")
        print()
        print()
        print()
        print()
        enter()
        exit()