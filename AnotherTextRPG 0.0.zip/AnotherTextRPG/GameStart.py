#####################################
#         Another Text RPG          #
#         By: Rush Deeter           #
# In Collaboration With: Kathy Orta #
#   Started work on Sept 9, 2020    #
#   Code inspired by Bryan Tong:    #
# https://www.youtube.com/watch?v=MFW8DJ6qsak&list=PL1-slM0ZOosXf2oQYZpTRAoeuo0TPiGpm




"""


This file contains the beginning of the
the game's loop. The code included is:

Classes:
    - Player_Character


"""



from MainGame import title_screen_image
from Equipment.Weapons import fists,fine_iron_ss
from Equipment.Armor import common_clothes, standard_iron_armor
from Equipment.Spells import fireslap,wimpyheal
from Equipment.Potions import wimpy_healing_potion,wimpy_mana_potion


#####   Player Setup   #####
class Player_Character:
    def __init__(self):

        self.name = ''

        self.job = ''
        self.lvl = 1
        self.xp = 0

        self.DEX = 10
        self.INT = 10
        self.STR = 10

        self.maxhp = 50
        self.hp = 50
        self.maxmp = 50
        self.mp = 50

        self.healing_spells_known = []
        self.damage_spells_known = []
        # - - - - - - - - - - - - - - - - - - - #
        self.status_effects = []

        self.weapon_equipped = fists
        self.spell_readied = ''
        self.armor_equipped = common_clothes
        # - - - - - - - - - - - - - - - - - - - #      
        self.gp = 0
        self.restoration_potions = []
        self.weapons = []
        self.armors = []
        # - - - - - - - - - - - - - - - - - - - #
        self.places_visited = []
        self.people_met = []        

        self.active_quests = ["ShepQuest"]
        self.completed_quests = []
        # - - - - - - - - - - - - - - - - - - - #
        self.current_map = {}
        self.quest_location = 'b2'
        self.location = 'L7'

        self.game_over = False 

#####   Defines the player under the Player_Character class   #####
my_player = Player_Character()


#####   Game Begins   #####
title_screen_image(my_player)

