#####################################
#         Another Text RPG          #
#         By: Rush Deeter           #
# In Collaboration With: Kathy Orta #



"""

This file is meant for functions that are used 
in most other files for this game. Currently,
the functions on this page include:

Functions:
    - inventory_display
    - equip_weapon
    - equip_armor


"""

import os
import time
from AcceptableLists import back
from Equipment.Weapons import weapons_dict, fists
from Equipment.Armor import armor_dict, common_clothes
from Equipment.Potions import restoration_potions_dict
from Adventures.Combat.Fighting import use_potion
from Looting import item_display
from AcceptableLists import armor_key, weapon_key, potion_key


def inventory_display(player):

    """

        Display's the player's options for
        their inventory and brings them to the 
        selected page.

    """

    choice = ''
    while choice != 'exit' and choice != 'e':
        print("\nInventory:\n")
        print("     Gold: %d \n" % player.gp)
        print("     Armor     (a)")
        print("     Weapons   (w)")
        print("     Potions   (p)")
        print("     Other     (o)")
        print("     Exit      (e)\n")

        choice = ''
        inventory = ["gold","g","other","o","exit","e"] + armor_key + weapon_key + potion_key
        while choice not in inventory:
            choice = input(" > ").lower().strip()

        if choice == 'exit' or choice == 'e': 
            os.system("cls")
            pass
        elif choice == "gold":
            print("Yep, %d gold." % player.gp)

        elif choice in armor_key:
            armor = armor_dict(player.armors)
            os.system("cls")
            print("                INVENTORY")
            if len(player.armors) == 0:
                print("You don't have any armor in your inventory.")

            armor_list = []
            for armors in player.armors:
                armor_list.append(armors.name)

            item_display(0, "armor", 40, player, armor,armor_list)
            equip_armor(player.armors, player)

        elif choice in weapon_key:
            weapons = weapons_dict(player.weapons)
            os.system("cls")
            print("                INVENTORY")
            if len(player.weapons) == 0:
                print("You don't have any weapons in your inventory.")

            weapons_list = []
            for weapon in player.weapons:
                weapons_list.append(weapon.name)

            item_display(0, "weapons", 40, player, weapons, weapons_list)
            equip_weapon(player.weapons, player)

        elif choice in potion_key:

            os.system("cls")
            print("                INVENTORY")
            if len(player.weapons) == 0:
                print("You don't have any potions in your inventory.")

            use_potion(player, "")
            
            
def equip_weapon(items, player):

    """

        Handles the equipping/unequipping process for weapons.

    """


    print("\nEquip a weapon? (back, unequip, or weapon name)\n")

    acceptable_options = back + ["unequip"]
    for item in items:
        if item.name not in acceptable_options:
            acceptable_options.append(item.name)

    choice = ''
    while choice not in acceptable_options:
        choice = input(" > ")

    if choice == "unequip":
        if player.weapon_equipped == fists:
            print("\nI don't think you want to remove those...")
            time.sleep(2)
        else:
            player.weapons.append(player.weapon_equipped)
            print("You unequip your %s." % player.weapon_equipped.name)
            player.weapon_equipped = fists
            time.sleep(2)
    for item in items:
        if item.name == choice:
            if player.weapon_equipped.name != 'fists':
                player.weapons.append(player.weapon_equipped)
            player.weapon_equipped = item
            print("\nYou equip the %s." % player.weapon_equipped.name)
            player.weapons.remove(item)
            time.sleep(2)


def equip_armor(items, player):

    """

        Handles the equipping/unequipping process for armor.

    """


    print("\nEquip armor? (back, unequip, or armor name)\n")

    acceptable_options = []
    for word in back:
        acceptable_options.append(word)

    acceptable_options.append("unequip")

    for item in items:
        if item.name not in acceptable_options:
            acceptable_options.append(item.name)

    choice = ''
    while choice not in acceptable_options:
        choice = input(" > ")

    if choice == "unequip":
        if player.armor_equipped == common_clothes:
            print("\nI don't think you want to remove those...")
            time.sleep(2)
        else:
            player.armors.append(player.armor_equipped)
            print("You unequip your %s." % player.armor_equipped.name)
            player.armor_equipped = common_clothes
            time.sleep(2)
    for item in items:
        if item.name == choice:
            if player.armor_equipped.name != 'cloth clothes':
                player.armors.append(player.armor_equipped)
            player.armor_equipped = item
            print("\nYou equip the %s." % player.armor_equipped.name)
            player.armors.remove(item)
            time.sleep(2)


