#####################################
#         Another Text RPG          #
#         By: Rush Deeter           #
# In Collaboration With: Kathy Orta #



"""


This file contains phrases that are commonly
used for the for map tiles.


"""



#####   Defining Global Variables   #####
TILE_NAME = 'name'
DESCRIPTION = 'describe'
EXAMINATION = 'examine'
QUEST = ''
WAS_QUEST_TEXT = 'area complete'
#QUEST_COMPLETED = False
#TOWN = False
UP = 'up', 'north'
DOWN = 'down', 'south'
LEFT = 'left', 'west'
RIGHT = 'right', 'east'



dirt_path_name = "Dirt Path"

dirt_path_describe_1 = "A path of dirt with stones strewn about."
dirt_path_examine_1 = "The dirt is very dry, some wafts into the air as you walk."


grass_name = "Grass"

grass_describe_1 = "Shin-high grass, blowing in the wind."
grass_examine_1 = "You kneel down and see some insects creating a home."


trees_name = "Grass"

trees_describe_1 = "Tall oak trees stand aound you."
trees_examine_1 = "The bare branches creak in the wind as you look around."


##########           Obstructions           ##########


wall_name = "Wall"

stone_wall_describe = "A wall made of stone."
stone_wall_examine = "The wall is cold to the touch."
stone_wall_stop = "You run into the wall."

wood_wall_describe = "A wall made of wood."
wood_wall_examine = "The wood is weatherd and moldy."


river_name = "River"

river_describe = "A flowing river."
river_examine = "A flowing river."
river_stop = "This river is uncrossable."