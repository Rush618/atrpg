#####################################
#         Another Text RPG          #
#         By: Rush Deeter           #
# In Collaboration With: Kathy Orta #



"""


This file contains the various lists 
to be used throughout the game while
the player is being asked for input.

Lists:
    - moving
    - inspecting
    - helping


"""



 # This is where i'll add 'fight', 'attack', 'potion', 'drink' etc.

accept = ['y','yes','sure','why not','i guess','ya','yeah','yuh','of course','course','mmm','ye','ye ye','yeye','si','porque no']

decline = ['n','no','nah','nope','never','im good',"i'm good"]

moving = ['go','travel','move','walk']

locating = ['where am i?','map','look far','location','show me'] 

directions = ['up','north','down','south','left','west','right','east', 'southeast' ,'southwest', 'northeast', 'northwest']

quick_move = ['go up', 'go north', 'go down', 'go south', 'go left', 'go west', 'go right', 'go east', 'go southeast', 'go southwest', 'go northeast', 'go northwest', 'travel up', 'travel north', 'travel down', 'travel south', 'travel left', 'travel west', 'travel right', 'travel east', 'travel southeast', 'travel southwest', 'travel northeast', 'travel northwest', 'move up', 'move north', 'move down', 'move south', 'move left', 'move west', 'move right', 'move east', 'move southeast', 'move southwest', 'move northeast', 'move northwest', 'walk up', 'walk north', 'walk down', 'walk south', 'walk left', 'walk west', 'walk right', 'walk east', 'walk southeast', 'walk southwest', 'walk northeast', 'walk northwest']

mistakes = ['nevermind','never mind','nowhere','nvm']
          
inspecting = ['look','examine','inspect','explore','look around']
              
helping = ['help','help me','please help','help please','pls help','help pls'] 

quitting = ['quit','q']

leaving = ['leave','l']

interacting = ['interact']

inventory = ["inventory","invent","inv"]

back = ["back", "b","return"]

weapon_key = ["weapons","w","wep","weapon"]

armor_key = ["armor","a","arm","armors"]

potion_key = ["potions","p","pot","potion"]



"""
new_move = []
for word in moving:
    for another in directions:
        combo = word + " " + another
        new_move.append(combo)

print(new_move)
"""