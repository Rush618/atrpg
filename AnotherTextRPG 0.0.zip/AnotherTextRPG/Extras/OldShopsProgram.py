#####################################
#         Another Text RPG          #
#         By: Rush Deeter           #
# In Collaboration With: Kathy Orta #



"""

This file's contents handle the interface
for shopkeepers. When the player asks to
see their wares, these functions are called:

Functions:
    - shopkeep_options
    - buying_options
    - selling options
    - weapons_display
    - dialogue options


"""



import os
import time
from random import randint
from Equipment.Weapons import *
from Equipment.Armor import armor_dict
from Utility import enter
from Looting import rolling_items,item_display
from AcceptableLists import mistakes, back, armor_key, weapon_key, potion_key



def shopkeep_options(player, shopkeep):

    """

        Displays the options when at a shopkeep.

    """

    print("What would you like to do?\n")
    print("     buy    (b)")
    print("     sell   (s)")
    print("     talk   (t)")
    print("     leave  (l)\n")


    choice = ''
    acceptable_options = ["buy", "b","sell","s","talk","t","leave","l"]
    while choice not in acceptable_options:
        choice = input(" > ")

    print()
    if choice == "leave" or choice ==  "l": pass
    elif choice == "buy" or choice == "b":
        buying_options(player,shopkeep)
    elif choice == "sell" or choice == "s":
        selling_options(player,shopkeep)
    elif choice == "talk" or choice ==  "t":
        dialogue_options(player,shopkeep)


def buying_options(player, shopkeep):

    """

        Displays the buying options for the given shopkeep.

    """

    acceptable_options = [] 

    print("\nWhat would you like to buy?\n")
    if "weapons" in shopkeep.item_types:
        print("     weapons  (w)")
        for word in weapon_key:
            acceptable_options.append(word)
    
    if "armor" in shopkeep.item_types:
        print("     armor    (a)")
        for word in armor_key:
            acceptable_options.append(word)

    if "potions" in shopkeep.item_types:
        print("     potions  (p)")
        for word in potion_key:
            acceptable_options.append(word)

    print("     back     (b)")
    for word in back:
        acceptable_options.append(word) 
    
    print()
    choice = ''
    print(acceptable_options)
    while choice not in acceptable_options:
        choice = input(" > ").lower().strip()

    if choice in back:
        print("shop_op")
        shopkeep_options(player, shopkeep)
    elif choice in weapon_key:
        shopkeep_item_display(1, "weapons", player, shopkeep.weapons, int(len(shopkeep.weapons)/2), shopkeep)
        #weapons_display(1, player,shopkeep.weapons,int(len(shopkeep.weapons)/2),shopkeep)
    elif choice in armor_key:
        shopkeep_item_display(1, "armor", player, shopkeep.weapons, int(len(shopkeep.weapons)/2), shopkeep)


def selling_options(player, shopkeep):

    """

        Displays the selling options for the given player.

    """

    acceptable_selling_options = []

    print("\nWhat would you like to sell?\n")

    if len(player.armors) > 0:
        print("     armor     (a)")
        for option in armor_key:
            acceptable_selling_options.append(option)

    if len(player.weapons) > 0:
        print("     weapons   (w)")
        for option in weapon_key:
            acceptable_selling_options.append(option)

    print("     back      (b)\n")
    for word in back:
        acceptable_selling_options.append(word)

    choice = ''
    while choice not in acceptable_selling_options:
        choice = input(" > ").lower().strip()

    if choice in back:
        shopkeep_options(player, shopkeep)
    elif choice in weapon_key:
        shopkeep_item_display(0, "weapons", player, player.weapons, len(player.weapons), shopkeep)
    elif choice in armor_key:
        shopkeep_item_display(0, "armor", player, player.armors, len(player.armors), shopkeep)


def weapons_display(buying, player, possible_weapons, number_weapons_desired, shopkeep):

    """

        Displays the weapons a shop is selling.

    """

    if buying == 1:
        weapons_for_sale = rolling_items(possible_weapons, number_weapons_desired)
    else: 
        weapons_for_sale = possible_weapons

    weapons = weapons_dict(weapons_for_sale)
    weapons_abbrev = []
    for item in weapons_for_sale:
        weapons_abbrev.append(item.abbrev)

    choice = ''
    while choice not in back and len(weapons_for_sale) > 0:
        os.system("cls")
        if buying == 1:
            print("                 BUYING")
        else:
            print("                 SELLING")

        item_display(1, 40, player, weapons)

        if buying == 1:
            print("\nAbbreviations:\n")
            for weapon in weapons_for_sale:
                print("     " + weapon.abbrev)

            print("\nInput an item you would like to purchase, or type 'back'.")

        elif buying == 0:
            print("\nInput an item you would like to sell, or type 'back'.")

        print("Current Gold: %d \n" % player.gp)

        choice = ''
        while choice not in back and choice not in weapons and choice not in weapons_abbrev:      
            choice = input(" > ").lower().strip()

        if choice in back: pass
        elif buying == 1: 
            for item in weapons_for_sale:
                    if item.name == choice or item.abbrev == choice:
                        if player.gp < item.value:
                            print("\nYou do not have enough gold to buy the " + choice + ".\n")
                            time.sleep(2)
                        else: 
                            print("\nYou hand over %d gold for the %s." % (item.value,item.name))
                            print("  -%d GP" % item.value)
                            player.weapons.append(item)
                            player.gp -= item.value
                            weapons_for_sale.remove(item)
                            weapons.pop(item.name)
                            time.sleep(2)
        elif buying == 0:
            for item in weapons_for_sale:
                    if item.name == choice:
                            weapons_for_sale.remove(item)
                            player.gp += item.value
                            weapons.pop(choice)

    if buying == 1:  buying_options(player, shopkeep)
    else:  selling_options(player,shopkeep)
                             

def shopkeep_item_display(buying, item_type, player, possible_items, number_items_desired, shopkeep):

    """

        Displays the weapons a shop is selling.

    """

    if buying == 1:
        items_for_sale = rolling_items(possible_items, number_items_desired)
    else: 
        items_for_sale = possible_items

    if item_type == "weapons":
        items = weapons_dict(items_for_sale)
    elif item_type == "armor":
        items = armor_dict(items_for_sale)

    abbreviations = []
    for item in items_for_sale:
        abbreviations.append(item.abbrev)

    choice = ''
    while choice not in back and len(items_for_sale) > 0:
        os.system("cls")
        if buying == 1:
            print("                 BUYING")
        else:
            print("                 SELLING")

        item_display(1, 40, player, items)

        print("\nAbbreviations:\n")
        for item in items_for_sale:
            print("     " + item.abbrev)

        if buying == 1:
            print("\nInput an item you would like to purchase, or type 'back'.")
        elif buying == 0:
            print("\nInput an item you would like to sell, or type 'back'.")

        print("Current Gold: %d \n" % player.gp)

        choice = ''
        while choice not in back and choice not in items and choice not in abbreviations:      
            choice = input(" > ").lower().strip()

        if choice in back: pass
        elif buying == 1: 
            for item in items_for_sale:
                    if item.name == choice or item.abbrev == choice:
                        if player.gp < item.value:
                            print("\nYou do not have enough gold to buy the " + choice + ".\n")
                            time.sleep(2)
                        else: 
                            print("\nYou hand over %d gold for the %s." % (item.value,item.name))
                            print("  -%d GP" % item.value)
                            if item_type == "weapons":
                                player.weapons.append(item)
                            elif item_type == "armor":
                                player.armors.append(item)
                            player.gp -= item.value
                            items_for_sale.remove(item)
                            items.pop(item.name)
                            time.sleep(2)
        elif buying == 0:
            for item in items_for_sale or item.abbrev == choice:
                    if item.name == choice:
                            print("\nYou hand over the %s for %d gold." % (item.name,item.value))
                            print("  +%d GP" % item.value)
                            items_for_sale.remove(item)
                            player.gp += item.value
                            items.pop(choice)
                            time.sleep(2)

    if buying == 1:  buying_options(player, shopkeep)
    else:  selling_options(player,shopkeep)


def dialogue_options(player, shopkeep):

    choice = ''
    while choice not in back:
        print("What would you like to talk about?\n")

        acceptable_options = [] + back
        for option in shopkeep.dialogue_options:
            print("     " + option)
            acceptable_options.append(option.lower())
        print("     back (b)\n")

        choice = ''
        while choice not in acceptable_options:
            choice = input(" > ")

        if choice in back: pass
        else:
            print("\n" + shopkeep.dialogue_options[choice])
            enter()

    shopkeep_options(player,shopkeep)



