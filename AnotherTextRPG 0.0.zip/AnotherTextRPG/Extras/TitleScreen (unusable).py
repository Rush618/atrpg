#####################################
#         Another Text RPG          #
#         By: Rush Deeter           #
# In Collaboration With: Kathy Orta #



"""


This file contains the title screen as
well as the help menu. The code included 
is as follows:

Functions:
    - title_screen_selection(player)
    - title_screen_image(player)
    - help_menu(player)


"""

import os
import sys
import cmd
import time 
from Utility import enter,text_display
#from MainGame import start_game




#####   Title Screen Functionality   #####
def title_screen_selection(player):
    title_options = ['play', 'help', 'quit', 'secret']
    selected = ""
    while selected not in title_options:  
        selected = input(" > ").lower()
    if selected == 'play':
        start_game(player)                                             
    elif selected == 'help':
        help_menu(player)
    elif selected == 'quit':
        exit()
    elif selected == 'secret':
        secret_happens(player)                                               


#####   ...   #####
def secret_happens(player):
    secret = "Keep it secret, keep it safe."
    text_display(secret,.1)
    enter()
    title_screen_image(player)


#####   Title Screen Display  ##### 
def title_screen_image(player):
    os.system("cls")
    print("#########################################")
    print("#     Welcome to Another Text RPG!      #")
    print("#########################################")
    print("               -  Play  -                ")
    print("               -  Help  -                ")
    print("               -  Quit  -                ")
    print("#########################################")
    title_screen_selection(player)

#####   Help Menu Display   #####
def help_menu(player):
    print(".........................................")
    print("                Help Menu                ")
    print(".........................................")
    print(" Explanation of the game and its basic   ")
    print(" controls (fighting, moving, examining,  ")
    print(" etc)")
    print(".........................................")
    enter()
    if player.game_over == True:
        title_screen_image(player)


