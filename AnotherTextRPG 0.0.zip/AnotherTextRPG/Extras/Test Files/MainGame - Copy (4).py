#####################################
#         Another Text RPG          #
#         By: Rush Deeter           #
# In Collaboration With: Kathy Orta #


import os
import sys
import cmd
import time 
import random
import textwrap


generic_text = []
with open("Descriptions/Generic.txt", "r") as myfile:
    for lines in myfile:
        generic_text.append(lines)






#####   Defining Global Variables   #####
#    Are these necessary???             #   
TILE_NAME = 'name'
DESCRIPTION = 'describe'
EXAMINATION = 'examine'
SOLVED = False
COMPLETED_TEXT = 'area complete'
UP = 'up', 'north'
DOWN = 'down', 'south'
LEFT = 'left', 'west'
RIGHT = 'right', 'east'

#####   Defining Explored Areas   #####
explored_locations = {'a1': False, 'a2': False, 'a3': False, 'a4': False, 
                     'b1': False, 'b2': False, 'b3': False, 'b4': False, 
                     'c1': False, 'c2': False, 'c3': False, 'c4': False, 
                     'd1': False, 'd2': False, 'd3': False, 'd4': False, 
}

##################      Need to get this to a different file for easier readability     ######################
#####   Setting up the Map   #####
world_map = {
    'field map': {
        'a1': {
            TILE_NAME: 'trees',
            DESCRIPTION: 'describe',
            EXAMINATION: 'examine',
            SOLVED: False,
            COMPLETED_TEXT: '',
            UP: '',
            DOWN: 'b2',
            LEFT: 'a1',
            RIGHT: 'a3',
        },   
        'a2': {
            TILE_NAME: 'trees',
            DESCRIPTION: 'describe',
            EXAMINATION: 'examine',
            SOLVED: False,
            COMPLETED_TEXT: '',
            UP: '',
            DOWN: ('down','south'),
            LEFT: ('left','west'),
            RIGHT: ('right','east'),
        },   
        'a3': {
            TILE_NAME: 'trees',
            DESCRIPTION: 'describe',
            EXAMINATION: 'examine',
            SOLVED: False,
            COMPLETED_TEXT: '',
            UP: '',
            DOWN: ('down','south'),
            LEFT: ('left','west'),
            RIGHT: ('right','east'),
        }, 
        'a4': {
            TILE_NAME: 'name',
            DESCRIPTION: 'describe',
            EXAMINATION: 'examine',
            SOLVED: False,
            COMPLETED_TEXT: '',
            UP: '',
            DOWN: ('down','south'),
            LEFT: ('left','west'),
            RIGHT: ('right','east'),
        }, 
        'b1': {
            TILE_NAME: 'Trees',
            DESCRIPTION: 'describe',
            EXAMINATION: 'examine',
            SOLVED: False,
            COMPLETED_TEXT: '',
            UP: ('up', 'north'),
            DOWN: ('down','south'),
            LEFT: ('left','west'),
            RIGHT: ('right','east'),
        },
        'b2': {
            TILE_NAME: 'The Shepherd',
            DESCRIPTION: 'You are surrounded by trees and see open fields to the south and west.',
            EXAMINATION: "You don't see much out of the ordinary, but to the southeast\n you hear the sound of bleating lambs...'baaa' 'baaaa'",
            SOLVED: False,
            COMPLETED_TEXT: 'complete',
            UP: 'a2',
            DOWN: 'c2',
            LEFT: 'b1',
            RIGHT: 'b3',
        },   
        'b3': {
            TILE_NAME: 'name',
            DESCRIPTION: 'describe',
            EXAMINATION: 'examine',
            SOLVED: False,
            COMPLETED_TEXT: '',
            UP: ('up', 'north'),
            DOWN: ('down','south'),
            LEFT: ('left','west'),
            RIGHT: ('right','east'),
        }, 
        'b4': {
            TILE_NAME: 'name',
            DESCRIPTION: 'describe',
            EXAMINATION: 'examine',
            SOLVED: False,
            COMPLETED_TEXT: '',
            UP: ('up', 'north'),
            DOWN: ('down','south'),
            LEFT: ('left','west'),
            RIGHT: ('right','east'),
        },
        'c1': {
            TILE_NAME: 'Trees',
            DESCRIPTION: 'describe',
            EXAMINATION: 'examine',
            SOLVED: False,
            COMPLETED_TEXT: '',
            UP: ('up', 'north'),
            DOWN: ('down','south'),
            LEFT: ('left','west'),
            RIGHT: ('right','east'),
        },
        'c2': {
            TILE_NAME: 'name',
            DESCRIPTION: 'describe',
            EXAMINATION: 'examine',
            SOLVED: False,
            COMPLETED_TEXT: '',
            UP: 'b2',
            DOWN: 'd2',
            LEFT: 'c1',
            RIGHT: 'c3',
        },   
        'c3': {
            TILE_NAME: 'name',
            DESCRIPTION: 'describe',
            EXAMINATION: 'examine',
            SOLVED: False,
            COMPLETED_TEXT: '',
            UP: ('up', 'north'),
            DOWN: ('down','south'),
            LEFT: ('left','west'),
            RIGHT: ('right','east'),
        }, 
        'c4': {
            TILE_NAME: 'name',
            DESCRIPTION: 'describe',
            EXAMINATION: 'examine',
            SOLVED: False,
            COMPLETED_TEXT: '',
            UP: ('up', 'north'),
            DOWN: ('down','south'),
            LEFT: ('left','west'),
            RIGHT: ('right','east'),
        },
        'd1': {
            TILE_NAME: 'name',
            DESCRIPTION: 'describe',
            EXAMINATION: 'examine',
            SOLVED: False,
            COMPLETED_TEXT: '',
            UP: ('up', 'north'),
            DOWN: ('down','south'),
            LEFT: ('left','west'),
            RIGHT: ('right','east'),
        },
        'd2': {
            TILE_NAME: 'name',
            DESCRIPTION: 'describe',
            EXAMINATION: 'examine',
            SOLVED: False,
            COMPLETED_TEXT: '',
            UP: ('up', 'north'),
            DOWN: ('down','south'),
            LEFT: ('left','west'),
            RIGHT: ('right','east'),
        },   
        'd3': {
            TILE_NAME: 'name',
            DESCRIPTION: 'describe',
            EXAMINATION: 'examine',
            SOLVED: False,
            COMPLETED_TEXT: '',
            UP: ('up', 'north'),
            DOWN: ('down','south'),
            LEFT: ('left','west'),
            RIGHT: ('right','east'),
        }, 
        'd4': {
            TILE_NAME: 'name',
            DESCRIPTION: 'describe',
            EXAMINATION: 'examine',
            SOLVED: False,
            COMPLETED_TEXT: '',
            UP: ('up', 'north'),
            DOWN: ('down','south'),
            LEFT: ('left','west'),
            RIGHT: ('right','east'),
        }
    }
}












#####   Player Setup   #####
class Player_Character:
    def __init__(self):
        self.name = ''
        self.job = ''
        self.super_location = 'field map'
        self.sub_location = 'b2'
        self.maxhp = 0
        self.hp = 0
        self.mp = 0
        self.status_effects = []
        self.game_over = False


my_player = Player_Character()














#####   Defines the 'enter' prompt, used to pace the text better   #####
def enter():
    print()
    input("(enter)")
    print()


#####   Displays text one character at a time at a specified rate   #####
def text_display(text,speed):
    for character in text:
        sys.stdout.write(character)
        sys.stdout.flush()
        time.sleep(speed)







#####   Title Screen Functionality   #####
def title_screen_selection():
    title_options = ['play', 'help', 'exit', 'secret']
    selected = ""
    while selected not in title_options:  
        selected = input(" > ")
    if selected.lower() == 'play':
        start_game()                                             
    elif selected.lower() == 'help':
        help_menu()
    elif selected.lower() == 'exit':
        exit()
    elif selected.lower() == 'secret':
        secret_happens()                                                # placeholder for secret function


#####   Title Screen Display  ##### 
def title_screen_image():
    os.system("cls")
    print("#########################################")
    print("#     Welcome to Another Text RPG!      #")
    print("#########################################")
    print("               -  Play  -                ")
    print("               -  Help  -                ")
    print("               -  Quit  -                ")
    print("#########################################")
    title_screen_selection()

#####   Help Menu Display   #####
def help_menu():
    print(".........................................")
    print("                Help Menu                ")
    print(".........................................")
    print(" Explanation of the game and its basic   ")
    print(" controls (fighting, moving, examining,  ")
    print(" etc)")
    print(".........................................")
    enter()
    title_screen_selection()


#####   Function displaying the player's current location   #####
def display_location():
    print('\n' + ('#' * (6 + len(world_map[my_player.super_location][my_player.sub_location][TILE_NAME]))))
    print('#  ',end='')
    print(world_map[my_player.super_location][my_player.sub_location][TILE_NAME],end='')
    print('  #')
    print('#' * (6 + len(world_map[my_player.super_location][my_player.sub_location][TILE_NAME])))
    if world_map[my_player.super_location][my_player.sub_location][SOLVED] is False:
        print(' - ' + world_map[my_player.super_location][my_player.sub_location][DESCRIPTION])


#####   Prompt which allows the player to interact with the world   #####
def prompt():
    print("\n" + "..........................")
    print("What would you like to do?")
    action = ''
    acceptable_actions = ['quit','go','travel','move','walk','look','examine','inspect','interact','explore']  # This is where i'll add 'fight', 'attack', 'potion', 'drink' etc.
    while action.lower() not in acceptable_actions:
        action = input(' > ')
    if action.lower() == 'quit':
        sys.exit()
    elif action.lower() in ['go', 'travel', 'move', 'walk']:
        player_movement(action.lower())                                                                              
    elif action.lower() in ['look', 'examine', 'inspect', 'interact','explore']:
        player_examine()                                             


#####   Asks the player where they want to move   #####
def player_movement(player_action):
    direction = ''
    valid_directions = ['up','north','down','south','left','west','right','east','nevermind','never mind','nowhere']
    print("Where would you like to " + player_action + "?")
    while direction not in valid_directions:
        direction = input(" > ").lower()
    if direction in ['up','north']:
        destination = world_map[my_player.super_location][my_player.sub_location][UP]
        movement_handler(destination, direction, player_action)
    elif direction in ['down','south']:
        destination = world_map[my_player.super_location][my_player.sub_location][DOWN]
        movement_handler(destination, direction, player_action)
    elif direction in ['left','west']:
        destination = world_map[my_player.super_location][my_player.sub_location][LEFT]
        movement_handler(destination, direction, player_action)
    elif direction in ['right','east']:
        destination = world_map[my_player.super_location][my_player.sub_location][RIGHT]
        movement_handler(destination, direction, player_action)
    elif direction in ['nevermind','never mind','nowhere']:
        pass


#####   Defines how the player moves through the map   #####
def movement_handler(destination, direction, player_action):
    if destination not in world_map[my_player.super_location]:                                                                         # This might need some tweaking, must not be able to go to invalid tiles
        movement_description = "That ain't it chief"
        text_display(movement_description,.02)
    elif destination in world_map[my_player.super_location]: 
        my_player.sub_location = destination
        movement_description = "You " + player_action + " " + direction.lower() + "."
        text_display(movement_description,.02)
        #print("You " + player_action + " " + direction.lower() + ".")
        display_location()


#####   Defines how the player observes the setting  #####
def player_examine():
    if world_map[my_player.super_location][my_player.sub_location][SOLVED]:
        examine_text = world_map[my_player.sub_location][COMPLETED_TEXT] + "\nYou have been here before."
        text_display(examine_text,.03)
    else: 
        examine_text = world_map[my_player.super_location][my_player.sub_location][EXAMINATION]
        text_display(examine_text,.03)
    return


#####   Where the user is prompted and the game actually happens...?   #####
def main_game_loop():
    while my_player.game_over is False:
        prompt()
        # Here we'll handle if puzzles have been solved, bosses defeated, explored everything, etc. 


#####   Function that starts the game   #####
def start_game():
    os.system('cls')
#####   This is an example of how we can slowly print the characters on the screen   #####
    #question1 = "Hello, what's your name?\n"
    introduction_text = []
    with open("Story/Introduction.txt", "r") as myfile:
        for lines in myfile:
            introduction_text.append(lines)

    
    text_display(introduction_text[0],.05)
    text_display(introduction_text[2],.03)
    text_display(introduction_text[4],.03)


    
    

    #for character in intro1:
    #    sys.stdout.write(character)
    #    sys.stdout.flush()
    #    time.sleep(.05)
    my_player.name = input("\n > ")
    display_location()
                                                                       #   This is where we'll put the first quest, so the player can decide their name.
                                                                       #   Maybe each quest has its own function or something...?
    main_game_loop()













#####   The game truly starts here. This function calls another function    #####
#####      which calls another which is what keeps the game running         #####
title_screen_image()

