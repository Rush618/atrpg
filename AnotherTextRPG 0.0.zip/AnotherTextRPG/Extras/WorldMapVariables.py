#####################################
#         Another Text RPG          #
#         By: Rush Deeter           #
# In Collaboration With: Kathy Orta #



"""


This file contains the infrastructure
for the world map.


"""



import os
import sys
import cmd
import time 
import random
import textwrap


#####   Defining Global Variables   #####
TILE_NAME = 'name'
DESCRIPTION = 'describe'
EXAMINATION = 'examine'
SOLVED = False
COMPLETED_TEXT = 'area complete'
QUEST = ''
#QUEST_COMPLETED = False
#TOWN = False
UP = 'up', 'north'
DOWN = 'down', 'south'
LEFT = 'left', 'west'
RIGHT = 'right', 'east'


