#####################################
#         Another Text RPG          #
#         By: Rush Deeter           #
# In Collaboration With: Kathy Orta #



"""

This file's contents handle the player's
looting process. The code included is:

Functions:
    - gold gain
    - rolling_items
    - item_display
    - display_current_weapon
    - display_current_armor
    - looting_options
    - enemy_item_display


"""



import time
from random import randint
from AcceptableLists import leaving, weapon_key, armor_key, potion_key
from Equipment.Weapons import weapons_dict



def gold_gain(amount, player):
    
    """

        Adds gold to the player's inventory and
        lets them know how much was added as well
        as how much gold they now have.

    """
    
    player.gp += amount
    print("+%d gold" % amount)
    print("Total GP: %d\n" % player.gp)
    time.sleep(1)


def rolling_items(possible_items, number_items_desired):

    """

        Uses a given list of possible items and a 
        desired number of items to create a new
        list of random items.

    """

    count = 0
    items_rolled = []
    upper_bound = len(possible_items) - 1

    while count < number_items_desired:
        number = randint(0, upper_bound)
        item = possible_items[number]

        if item not in items_rolled:
            items_rolled.append(item)
            upper_bound -= 1
            count += 1
        else: pass

    return items_rolled


def item_display(for_shopkeep, item_type, menu_length, player, wares_dict,wares_list):

    """

        Displayes a menu of specified length. The
        menu displays a given set of wares as well as
        their specifications which are listed elsewhere.

    """

    for key, value in wares_dict.items():
        key_length = len(key)
    
        # Use something like this to keep the map more centered
        if key_length % 2 == 0:
            num_hashes_1 = int((menu_length - key_length) / 2) - 4
            num_hashes_2 = num_hashes_1 - 1
        else: 
            num_hashes_1 = int((menu_length - key_length) / 2) - 4
            num_hashes_2 = num_hashes_1

        print('\n' + '-'*num_hashes_1, "  ", key, "  ", '-'*num_hashes_2 + " (" + str(wares_list.count(key)) + ")")

        for descriptor, description in value.items():
            print(descriptor, ': ', description)

    if item_type == "weapons":
        display_current_weapon(player)
    elif item_type == "armor":
        display_current_armor(player)


def display_current_weapon(player):

    """

        Displays the player's current weapon and 
        its relevant stats.

    """

    name_length = len(player.weapon_equipped.name)

    if name_length % 2 == 0:
        num_hashes_1 = int((40 - name_length) / 2) - 4
        num_hashes_2 = num_hashes_1 - 1
    else: 
        num_hashes_1 = int((40 - name_length) / 2) - 4
        num_hashes_2 = num_hashes_1
    
    print("\n\n\nCurently Equipped:")
    print('\n' + '*'*num_hashes_1, "  ", player.weapon_equipped.name, "  ", '*'*num_hashes_2 + '\n')
    print("Min: %d" % player.weapon_equipped.min_dmg)
    print("Max: %d" % player.weapon_equipped.max_dmg)
    print("Value: %d" % player.weapon_equipped.value)


def display_current_armor(player):

    """

        Displays the player's current weapon and 
        its relevant stats.

    """

    name_length = len(player.armor_equipped.name)

    if name_length % 2 == 0:
        num_hashes_1 = int((40 - name_length) / 2) - 4
        num_hashes_2 = num_hashes_1 - 1
    else: 
        num_hashes_1 = int((40 - name_length) / 2) - 4
        num_hashes_2 = num_hashes_1
    
    print("\n\n\nCurently Equipped:")
    print('\n' + '*'*num_hashes_1, "  ", player.armor_equipped.name, "  ", '*'*num_hashes_2 + '\n')
    print("Defense: %d" % player.armor_equipped.defense)
    print("Value: %d" % player.armor_equipped.value)


def looting_options(player, enemy):

    """

        Displays the lototing options for the given enemy.

    """

    acceptable_options = [] 

    print("\nWhat would you like to take?\n")
    if "weapons" in enemy.item_types:
        print("     weapons  (w)")
        for word in weapon_key:
            acceptable_options.append(word)
    
    if "armor" in enemy.item_types:
        print("     armor    (a)")
        for word in armor_key:
            acceptable_options.append(word)

    if "potions" in enemy.item_types:
        print("     potions  (p)")
        for word in potion_key:
            acceptable_options.append(word)

    print("     leave    (l)\n")
    for word in leaving:
        acceptable_options.append(word) 
    
    choice = ''
    while choice not in acceptable_options:
        choice = input(" > ").lower().strip()

    if choice in leaving: pass
    elif choice in weapon_key:
        enemy_item_display(enemy, "weapons", player)
    elif choice in armor_key:
        enemy_item_display(enemy, "armor", player)


def enemy_item_display(enemy, item_type, player):


    if item_type == "weapons":
        items = weapons_dict(enemy.weapons)
        items_to_loot = enemy.weapons
    elif item_type == "armor":
        items = armor_dict(enemy.armor)
        items_to_loot = enemy.armor
    elif item_type == "potions":
        items = armor_dict(enemy.potions)
        items_to_loot = enemy.potions


    abbreviations = []
    for item in items_to_loot:
        abbreviations.append(item.abbrev)

    choice = ''
    while choice not in leaving and len(items_to_loot) > 0:

        item_display(0, item_type, 40, player, items)

        print("\nAbbreviations:\n")
        for abbreviation in abbreviations:
            print("     " + abbreviation)

        choice = ''
        while choice not in leaving and choice not in items and choice not in abbreviations:      
            choice = input(" > ").lower().strip()

        if choice in leaving: pass
        else:
            for item in items_to_loot:
                if item.name == choice or item.abbrev == choice:
                    if item_type == "weapons":
                        player.weapons.append(item)
                    elif item_type == "armor":
                        player.armors.append(item)
                    print("You grab the %s and put it in your pack." % item.name)
                    items_to_loot.remove(item)
                    items.pop(item.name)
                    abbreviations.remove(item.abbrev)
                    time.sleep(2)