#####################################
#         Another Text RPG          #
#         By: Rush Deeter           #
# In Collaboration With: Kathy Orta #



"""

This file is meant for functions that are used 
in most other files for this game. Currently,
the functions on this page include:

Functions:
    - new_mapping


"""



from WorldMapFile import *



#####################################
#         Another Text RPG          #
#         By: Rush Deeter           #
# In Collaboration With: Kathy Orta #



"""

This file is meant for functions that are used 
in most other files for this game. Currently,
the functions on this page include:

Functions:
    - new_mapping


"""



from WorldMapFile import *



def new_mapping(location,map_type):
    
    """

        Displays the players location relative to
        the surrounding tiles. Nine total tiles
        are displayed through this function.

    """
    
    center_name = map_type[location][TILE_NAME]

    if map_type[location][UP] in map_type:
        north = map_type[location][UP]
        north_name = map_type[north][TILE_NAME]
        if map_type[north][RIGHT] in map_type:
            northeast = map_type[north][RIGHT]
            northeast_name = map_type[northeast][TILE_NAME]
        else: northeast_name = "N/A"
        if map_type[north][LEFT] in map_type:
            northwest = map_type[north][LEFT]
            northwest_name = map_type[northwest][TILE_NAME]
        else: northwest_name = "N/A"
    else:
        northeast_name = "N/A"
        northwest_name = "N/A"
        north_name = "N/A"

    if map_type[location][DOWN] in map_type:
        south = map_type[location][DOWN]
        south_name = map_type[south][TILE_NAME]
        if map_type[south][RIGHT] in map_type:
            southeast = map_type[south][RIGHT]
            southeast_name = map_type[southeast][TILE_NAME]
        else: southeast_name = "N/A"
        if map_type[south][LEFT] in map_type:
            southwest = map_type[south][LEFT]
            southwest_name = map_type[southwest][TILE_NAME]
        else: southwest_name = "N/A"
    else: 
        southeast_name = "N/A"
        southwest_name = "N/A"
        south_name = "N/A"

    if map_type[location][RIGHT] in map_type:
        east = map_type[location][RIGHT]
        east_name = map_type[east][TILE_NAME]
        if map_type[east][UP] in map_type:
            northeast = map_type[east][UP]
            northeast_name = map_type[northeast][TILE_NAME]
        else: northeast_name = "N/A"
        if map_type[east][DOWN] in map_type:
            southeast = map_type[east][DOWN]
            southeast_name = map_type[southeast][TILE_NAME]
        else: southeast_name = "N/A"
    else: east_name = "N/A"

    if map_type[location][LEFT] in map_type:
        west = map_type[location][LEFT]
        west_name = map_type[west][TILE_NAME]
        if map_type[west][UP] in map_type:
            northwest = map_type[west][UP]
            northwest_name = map_type[northwest][TILE_NAME]
        else: northwest_name = "N/A"
        if map_type[west][DOWN] in map_type:
            southwest = map_type[west][DOWN]
            southwest_name = map_type[southwest][TILE_NAME]
        else: southwest_name = "N/A"
    else: west_name = "N/A"


    maximum = 0
    max_value = ""
    values = [north_name,south_name,east_name,west_name,northeast_name,northwest_name,southeast_name,southwest_name,center_name]
    for value in values:
        length = len(value)
        if length > maximum:
            maximum = length

    box_width = (6 + maximum) + 2
    c_spaces = int((box_width - len(center_name)) / 2)
    n_spaces = int((box_width - len(north_name)) / 2)
    s_spaces = int((box_width - len(south_name)) / 2)
    e_spaces = int((box_width - len(east_name)) / 2)
    w_spaces = int((box_width - len(west_name)) / 2)
    ne_spaces = int((box_width - len(northeast_name)) / 2)
    nw_spaces = int((box_width - len(northwest_name)) / 2)
    se_spaces = int((box_width - len(southeast_name)) / 2)
    sw_spaces = int((box_width - len(southwest_name)) / 2)


    print('\n\n' + ('=' * (3 * (6 + maximum) + 4)))
    print("#" + (" " * (6 + maximum)) + "#" + (" " * (6 + maximum)) + "#" + (" " * (6 + maximum)) + "#")
    print("#" + (" " * (6 + maximum)) + "#" + (" " * (6 + maximum)) + "#" + (" " * (6 + maximum)) + "#")
    print((" " * nw_spaces) + northwest_name + (" " * nw_spaces) + (" " * n_spaces) + north_name + (" " * n_spaces) + (" " * ne_spaces) + northeast_name + (" " * ne_spaces))
    print("#" + (" " * (6 + maximum)) + "#" + (" " * (6 + maximum)) + "#" + (" " * (6 + maximum)) + "#")
    print("#" + (" " * (6 + maximum)) + "#" + (" " * (6 + maximum)) + "#" + (" " * (6 + maximum)) + "#")
    print('=' * (3 * (6 + maximum) + 4))
    print("#" + (" " * (6 + maximum)) + "#" + (" " * (6 + maximum)) + "#" + (" " * (6 + maximum)) + "#")
    print("#" + (" " * (6 + maximum)) + "#" + (" " * (6 + maximum)) + "#" + (" " * (6 + maximum)) + "#")
    print((" " * w_spaces) + west_name + (" " * w_spaces) + (" " * c_spaces) + center_name + (" " * c_spaces) + (" " * e_spaces) + east_name + (" " * e_spaces))
    print("#" + (" " * (6 + maximum)) + "#" + (" " * (6 + maximum)) + "#" + (" " * (6 + maximum)) + "#")
    print("#" + (" " * (6 + maximum)) + "#" + (" " * (6 + maximum)) + "#" + (" " * (6 + maximum)) + "#")
    print('=' * (3 * (6 + maximum) + 4))
    print("#" + (" " * (6 + maximum)) + "#" + (" " * (6 + maximum)) + "#" + (" " * (6 + maximum)) + "#")
    print("#" + (" " * (6 + maximum)) + "#" + (" " * (6 + maximum)) + "#" + (" " * (6 + maximum)) + "#")
    print((" " * sw_spaces) + southwest_name + (" " * sw_spaces) + (" " * s_spaces) + south_name + (" " * s_spaces) + (" " * se_spaces) + southeast_name + (" " * se_spaces))
    print("#" + (" " * (6 + maximum)) + "#" + (" " * (6 + maximum)) + "#" + (" " * (6 + maximum)) + "#")
    print("#" + (" " * (6 + maximum)) + "#" + (" " * (6 + maximum)) + "#" + (" " * (6 + maximum)) + "#")
    print('=' * (3 * (6 + maximum) + 4))



"""
def new_mapping(location,map_type):
    


        #Attempting to allow tole names that are inaccessible to still have a name instead of N/A



    center_name = map_type[location][TILE_NAME]

    north = map_type[location][UP]
    north_name = map_type[north][TILE_NAME]

    northeast = map_type[north][RIGHT]
    northeast_name = map_type[northeast][TILE_NAME]

    northwest = map_type[north][LEFT]
    northwest_name = map_type[northwest][TILE_NAME]

    south = map_type[location][DOWN]
    south_name = map_type[south][TILE_NAME]

    southeast = map_type[south][RIGHT]
    southeast_name = map_type[southeast][TILE_NAME]

    southwest = map_type[south][LEFT]
    southwest_name = map_type[southwest][TILE_NAME]

    east = map_type[location][RIGHT]
    east_name = map_type[east][TILE_NAME]


    if map_type[location][RIGHT] in map_type:
        east = map_type[location][RIGHT]
        east_name = map_type[east][TILE_NAME]
        if map_type[east][UP] in map_type:
            northeast = map_type[east][UP]
            northeast_name = map_type[northeast][TILE_NAME]
        else: northeast_name = "N/A"
        if map_type[east][DOWN] in map_type:
            southeast = map_type[east][DOWN]
            southeast_name = map_type[southeast][TILE_NAME]
        else: southeast_name = "N/A"
    else: east_name = "N/A"

    if map_type[location][LEFT] in map_type:
        west = map_type[location][LEFT]
        west_name = map_type[west][TILE_NAME]
        if map_type[west][UP] in map_type:
            northwest = map_type[west][UP]
            northwest_name = map_type[northwest][TILE_NAME]
        else: northwest_name = "N/A"
        if map_type[west][DOWN] in map_type:
            southwest = map_type[west][DOWN]
            southwest_name = map_type[southwest][TILE_NAME]
        else: southwest_name = "N/A"
    else: west_name = "N/A"


    maximum = 0
    max_value = ""
    values = [north_name,south_name,east_name,west_name,northeast_name,northwest_name,southeast_name,southwest_name,center_name]
    for value in values:
        length = len(value)
        if length > maximum:
            maximum = length

    box_width = (6 + maximum) + 2
    c_spaces = int((box_width - len(center_name)) / 2)
    n_spaces = int((box_width - len(north_name)) / 2)
    s_spaces = int((box_width - len(south_name)) / 2)
    e_spaces = int((box_width - len(east_name)) / 2)
    w_spaces = int((box_width - len(west_name)) / 2)
    ne_spaces = int((box_width - len(northeast_name)) / 2)
    nw_spaces = int((box_width - len(northwest_name)) / 2)
    se_spaces = int((box_width - len(southeast_name)) / 2)
    sw_spaces = int((box_width - len(southwest_name)) / 2)


    print('\n\n' + ('=' * (3 * (6 + maximum) + 4)))
    print("#" + (" " * (6 + maximum)) + "#" + (" " * (6 + maximum)) + "#" + (" " * (6 + maximum)) + "#")
    print("#" + (" " * (6 + maximum)) + "#" + (" " * (6 + maximum)) + "#" + (" " * (6 + maximum)) + "#")
    print((" " * nw_spaces) + northwest_name + (" " * nw_spaces) + (" " * n_spaces) + north_name + (" " * n_spaces) + (" " * ne_spaces) + northeast_name + (" " * ne_spaces))
    print("#" + (" " * (6 + maximum)) + "#" + (" " * (6 + maximum)) + "#" + (" " * (6 + maximum)) + "#")
    print("#" + (" " * (6 + maximum)) + "#" + (" " * (6 + maximum)) + "#" + (" " * (6 + maximum)) + "#")
    print('=' * (3 * (6 + maximum) + 4))
    print("#" + (" " * (6 + maximum)) + "#" + (" " * (6 + maximum)) + "#" + (" " * (6 + maximum)) + "#")
    print("#" + (" " * (6 + maximum)) + "#" + (" " * (6 + maximum)) + "#" + (" " * (6 + maximum)) + "#")
    print((" " * w_spaces) + west_name + (" " * w_spaces) + (" " * c_spaces) + center_name + (" " * c_spaces) + (" " * e_spaces) + east_name + (" " * e_spaces))
    print("#" + (" " * (6 + maximum)) + "#" + (" " * (6 + maximum)) + "#" + (" " * (6 + maximum)) + "#")
    print("#" + (" " * (6 + maximum)) + "#" + (" " * (6 + maximum)) + "#" + (" " * (6 + maximum)) + "#")
    print('=' * (3 * (6 + maximum) + 4))
    print("#" + (" " * (6 + maximum)) + "#" + (" " * (6 + maximum)) + "#" + (" " * (6 + maximum)) + "#")
    print("#" + (" " * (6 + maximum)) + "#" + (" " * (6 + maximum)) + "#" + (" " * (6 + maximum)) + "#")
    print((" " * sw_spaces) + southwest_name + (" " * sw_spaces) + (" " * s_spaces) + south_name + (" " * s_spaces) + (" " * se_spaces) + southeast_name + (" " * se_spaces))
    print("#" + (" " * (6 + maximum)) + "#" + (" " * (6 + maximum)) + "#" + (" " * (6 + maximum)) + "#")
    print("#" + (" " * (6 + maximum)) + "#" + (" " * (6 + maximum)) + "#" + (" " * (6 + maximum)) + "#")
    print('=' * (3 * (6 + maximum) + 4))
"""

