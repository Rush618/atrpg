#####################################
#         Another Text RPG          #
#         By: Rush Deeter           #
# In Collaboration With: Kathy Orta #



"""


This file contains the basic componets
of the game and starts it through the 
titel screen. The code included is:

Classes:
    - Player_Character

Functions:
    - title_screen_selection()
    - title_screen_image()
    - title_help_menu()
    - main_game_loop()
    - start_game()


"""



import os
import sys
import cmd
import time 
import random
import textwrap
from Utility import enter,text_display
from Prompting import prompt
from WorldMapFile import world_map
from Adventures.Questing import quest_locator
from Civilization.Towning import town_locator


def title_screen_selection(player):
    
    """

        Prompts the player and continues when one of the 
        ptions from the title screen is entered.

    """
    
    title_options = ['play', 'help', 'quit', 'secret']
    selected = ""
    while selected not in title_options:  
        selected = input(" > ").lower().strip()
    if selected == 'play':
        start_game(player)                                             
    elif selected == 'help':
        title_help_menu(player)
    elif selected == 'quit':
        exit()
    elif selected == 'secret':
        secret_happens(player)                                               


def secret_happens(player):
    text_display("Keep it secret, keep it safe.",.1)
    enter()
    title_screen_image(player)


def title_screen_image(player):
    
    """

        Clears the window and displays the 
        title screen menu.

    """
    
    os.system("cls")
    print("#########################################")
    print("#     Welcome to Another Text RPG!      #")
    print("#########################################")
    print("               -  Play  -                ")
    print("               -  Help  -                ")
    print("               -  Quit  -                ")
    print("#########################################")
    title_screen_selection(player)


def title_help_menu(player):
    
    """

        Displays the Help menu for the Title Screen.
        This help menu will let the player know 
        that future help menus will be updated with 
        valid commands for there current location as 
        they are discovered by the player.

    """
    
    print(".........................................")
    print("                Help Menu                ")
    print(".........................................")
    print(" Explanation of the game and its basic   ")
    print(" controls (fighting, moving, examining,  ")
    print(" etc)")
    print("Commands are not case-sensitive")
    print(".........................................")
    enter()
    title_screen_image(player)


def main_game_loop(player):
    
    """

        Continuously prompts the player until
        the game is over. This is the main
        engine that keeps the game running.

    """
    
    player.current_map = world_map
    while player.game_over is False:

        quest_locator(player)
        town_locator(player)

        prompt(player, player.current_map)      


def start_game(player):
    
    """

        This function 'starts the game' but it seems
        unnecesasry so I might remove it later and
        move its parts to other functions.

    """
    
    os.system('cls')
    player.game_over = False
    main_game_loop(player)

