#####################################
#         Another Text RPG          #
#         By: Rush Deeter           #
# In Collaboration With: Kathy Orta #



"""


This file lays out the quests in the game.

Functions:
    - quest_locator


"""



from .ShepQuest import shepherd_quest
from .MushroomMania import mushroom_mania



def quest_locator(player):
    
    """

        Checks the player's location, if there's a quest 
        associated with it then that quest is started.

    """
    
    if player.location == 'L7' and "ShepQuest" in player.active_quests:
        shepherd_quest(player) 
    elif player.location == 'F9' and "MushroomMania" not in player.completed_quests:
        mushroom_mania(player) 



