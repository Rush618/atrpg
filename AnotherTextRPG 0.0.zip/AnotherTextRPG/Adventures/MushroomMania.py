#####################################
#         Another Text RPG          #
#         By: Rush Deeter           #
# In Collaboration With: Kathy Orta #



"""


This file lays out the mushroom quest. 
Here the player travels through the Mushroom 
Tunnels and has a chance to talk to the Mushroom
King and learn some cool stuff. The files
included are:

Dictionaries:
    - mush_map
    - mush_checkpoints

Functions:
    - mush_intro
    - mushroom_mania


"""



from Looting import gold_gain
from WorldMapFile import world_map
from Utility import enter,text_display
from AcceptableLists import accept,decline
from MapPhrases import *
from .QuestPrompting import quest_prompt
from .Combat.Fighting import *



mush_text = []
with open("Adventures/MushroomManiaText.txt", "r") as myfile:
    for lines in myfile:
        mush_text.append(lines)

#shep_lore = []
#with open("Story/ShepLore.txt", "r") as myfile:
#    for lines in myfile:
#        shep_lore.append(lines)


TILE_NAME = 'name'
DESCRIPTION = 'describe'
EXAMINATION = 'examine'        
DOOR = 'none'
COMPLETED_TEXT = 'area complete'
UP = 'up', 'north'
DOWN = 'down', 'south'
LEFT = 'left', 'west'
RIGHT = 'right', 'east'


mush_map = {
    'a2': {
        TILE_NAME: wall_name,
        DESCRIPTION: stone_wall_describe,
        EXAMINATION: stone_wall_examine,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: '',
        DOWN: 'b2',
        LEFT: '',
        RIGHT: 'a3',
    },   
    'a3': {
        TILE_NAME: wall_name,
        DESCRIPTION: stone_wall_describe,
        EXAMINATION: stone_wall_examine,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: '',
        DOWN: 'b3',
        LEFT: 'a2',
        RIGHT: 'a4',
    }, 
    'a4': {
        TILE_NAME: wall_name,
        DESCRIPTION: stone_wall_describe,
        EXAMINATION: stone_wall_examine,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: '',
        DOWN: 'b4',
        LEFT: 'a3',
        RIGHT: 'a5',
    }, 
    'a5': {
        TILE_NAME: wall_name,
        DESCRIPTION: stone_wall_describe,
        EXAMINATION: stone_wall_examine,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: '',
        DOWN: 'b5',
        LEFT: 'a4',
        RIGHT: 'a6',
    },
    'a6': {
        TILE_NAME: wall_name,
        DESCRIPTION: stone_wall_describe,
        EXAMINATION: stone_wall_examine,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: '',
        DOWN: 'b6',
        LEFT: 'a5',
        RIGHT: 'a7',
    },
    'a7': {
        TILE_NAME: wall_name,
        DESCRIPTION: stone_wall_describe,
        EXAMINATION: stone_wall_examine,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: '',
        DOWN: 'b7',
        LEFT: 'a6',
        RIGHT: 'a8',
    },
    'a8': {
        TILE_NAME: wall_name,
        DESCRIPTION: stone_wall_describe,
        EXAMINATION: stone_wall_examine,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: '',
        DOWN: 'b8',
        LEFT: 'a7',
        RIGHT: 'a9',
    },
    'a9': {
        TILE_NAME: wall_name,
        DESCRIPTION: stone_wall_describe,
        EXAMINATION: stone_wall_examine,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: '',
        DOWN: 'b9',
        LEFT: 'a8',
        RIGHT: 'a10',
    },
    'a10': {
        TILE_NAME: wall_name,
        DESCRIPTION: stone_wall_describe,
        EXAMINATION: stone_wall_examine,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: '',
        DOWN: 'b10',
        LEFT: 'a9',
        RIGHT: 'a11',
    },
    'a11': {
        TILE_NAME: wall_name,
        DESCRIPTION: stone_wall_describe,
        EXAMINATION: stone_wall_examine,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: '',
        DOWN: 'b11',
        LEFT: 'a10',
        RIGHT: 'a12',
    },
    'a12': {
        TILE_NAME: wall_name,
        DESCRIPTION: stone_wall_describe,
        EXAMINATION: stone_wall_examine,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: '',
        DOWN: 'b12',
        LEFT: 'a11',
        RIGHT: '',
    },
    'b2': {
        TILE_NAME: wall_name,
        DESCRIPTION: stone_wall_describe,
        EXAMINATION: stone_wall_examine,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'a2',
        DOWN: 'c2',
        LEFT: '',
        RIGHT: 'b3',
    },   
    'b3': {
        TILE_NAME: dirt_path_name,
        DESCRIPTION: dirt_path_describe_1,
        EXAMINATION: dirt_path_examine_1,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'a3',
        DOWN: 'c3',
        LEFT: 'b2',
        RIGHT: 'b4',
    }, 
    'b4': {
        TILE_NAME: dirt_path_name,
        DESCRIPTION: dirt_path_describe_1,
        EXAMINATION: dirt_path_examine_1,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'a4',
        DOWN: 'c4',
        LEFT: 'b3',
        RIGHT: 'b5',
    },
    'b5': {
        TILE_NAME: dirt_path_name,
        DESCRIPTION: dirt_path_describe_1,
        EXAMINATION: dirt_path_examine_1,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'a5',
        DOWN: 'c5',
        LEFT: 'b4',
        RIGHT: 'b6',
    },
    'b6': {
        TILE_NAME: dirt_path_name,
        DESCRIPTION: dirt_path_describe_1,
        EXAMINATION: dirt_path_examine_1,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'a6',
        DOWN: 'c6',
        LEFT: 'b5',
        RIGHT: 'b7',
    },
    'b7': {
        TILE_NAME: wall_name,
        DESCRIPTION: stone_wall_describe,
        EXAMINATION: stone_wall_examine,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'a7',
        DOWN: 'c7',
        LEFT: 'b6',
        RIGHT: 'b8',
    },
    'b9': {
        TILE_NAME: wall_name,
        DESCRIPTION: stone_wall_describe,
        EXAMINATION: stone_wall_examine,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'a9',
        DOWN: 'c9',
        LEFT: 'b8',
        RIGHT: 'b10',
    },
    'b10': {
        TILE_NAME: dirt_path_name,
        DESCRIPTION: dirt_path_describe_1,
        EXAMINATION: dirt_path_examine_1,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'a10',
        DOWN: 'c10',
        LEFT: 'b9',
        RIGHT: 'b11',
    },
    'b11': {
        TILE_NAME: 'Mossy Chest',
        DESCRIPTION: 'A wooden chest with moss consuming it.',
        EXAMINATION: "Brushing away some of the moss, you find a keyhole.",
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'a11',
        DOWN: 'c11',
        LEFT: 'b10',
        RIGHT: 'b12',
    },
    'b12': {
        TILE_NAME: wall_name,
        DESCRIPTION: stone_wall_describe,
        EXAMINATION: stone_wall_examine,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'a12',
        DOWN: 'c12',
        LEFT: 'b11',
        RIGHT: '',
    },
    'c1': {
        TILE_NAME: wall_name,
        DESCRIPTION: stone_wall_describe,
        EXAMINATION: stone_wall_examine,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: '',
        DOWN: 'd1',
        LEFT: '',
        RIGHT: 'c2',
    },
    'c2': {
        TILE_NAME: wall_name,
        DESCRIPTION: stone_wall_describe,
        EXAMINATION: stone_wall_examine,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'b2',
        DOWN: 'd2',
        LEFT: 'c1',
        RIGHT: 'c3',
    },   
    'c3': {
        TILE_NAME: dirt_path_name,
        DESCRIPTION: dirt_path_describe_1,
        EXAMINATION: dirt_path_examine_1,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'b3',
        DOWN: 'd3',
        LEFT: 'c2',
        RIGHT: 'c4',
    }, 
    'c4': {
        TILE_NAME: wall_name,
        DESCRIPTION: stone_wall_describe,
        EXAMINATION: stone_wall_examine,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'b4',
        DOWN: 'd4',
        LEFT: 'c3',
        RIGHT: 'c5',
    },
    'c5': {
        TILE_NAME: wall_name,
        DESCRIPTION: stone_wall_describe,
        EXAMINATION: stone_wall_examine,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'b5',
        DOWN: 'd5',
        LEFT: 'c4',
        RIGHT: 'c6',
    },
    'c6': {
        TILE_NAME: dirt_path_name,
        DESCRIPTION: dirt_path_describe_1,
        EXAMINATION: dirt_path_examine_1,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'b6',
        DOWN: 'd6',
        LEFT: 'c5',
        RIGHT: 'c7',
    },
    'c7': {
        TILE_NAME: wall_name,
        DESCRIPTION: stone_wall_describe,
        EXAMINATION: stone_wall_examine,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'b7',
        DOWN: 'd7',
        LEFT: 'c6',
        RIGHT: 'c8',
    },
    'c8': {
        TILE_NAME: wall_name,
        DESCRIPTION: stone_wall_describe,
        EXAMINATION: stone_wall_examine,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'b8',
        DOWN: 'd8',
        LEFT: 'c7',
        RIGHT: 'c7',
    },
    'c9': {
        TILE_NAME: wall_name,
        DESCRIPTION: stone_wall_describe,
        EXAMINATION: stone_wall_examine,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'b9',
        DOWN: 'd9',
        LEFT: 'c8',
        RIGHT: 'c10',
    },
    'c10': {
        TILE_NAME: dirt_path_name,
        DESCRIPTION: dirt_path_describe_1,
        EXAMINATION: dirt_path_examine_1,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'b10',
        DOWN: 'd10',
        LEFT: 'c9',
        RIGHT: 'c11',
    },
    'c11': {
        TILE_NAME: dirt_path_name,
        DESCRIPTION: dirt_path_describe_1,
        EXAMINATION: dirt_path_examine_1,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'b11',
        DOWN: 'd11',
        LEFT: 'c10',
        RIGHT: 'c12',
    },
    'c12': {
        TILE_NAME: wall_name,
        DESCRIPTION: stone_wall_describe,
        EXAMINATION: stone_wall_examine,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'b12',
        DOWN: 'd12',
        LEFT: 'c11',
        RIGHT: '',
    },
    'd1': {
        TILE_NAME: wall_name,
        DESCRIPTION: stone_wall_describe,
        EXAMINATION: stone_wall_examine,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'c1',
        DOWN: 'e1',
        LEFT: '',
        RIGHT: 'd2',
    },
    'd2': {
        TILE_NAME: dirt_path_name,
        DESCRIPTION: dirt_path_describe_1,
        EXAMINATION: dirt_path_examine_1,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'c2',
        DOWN: 'e2',
        LEFT: 'd1',
        RIGHT: 'd3',
    },   
    'd3': {
        TILE_NAME: dirt_path_name,
        DESCRIPTION: dirt_path_describe_1,
        EXAMINATION: dirt_path_examine_1,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'c3',
        DOWN: 'e3',
        LEFT: 'd2',
        RIGHT: 'd4',
    }, 
    'd4': {
        TILE_NAME: wall_name,
        DESCRIPTION: stone_wall_describe,
        EXAMINATION: stone_wall_examine,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'c4',
        DOWN: 'e4',
        LEFT: 'd3',
        RIGHT: 'd5',
    },
    'd5': {
        TILE_NAME: "Exit",
        DESCRIPTION: "The path to the surface.",
        EXAMINATION: "Exactly what you thought.",
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'c5',
        DOWN: 'e5',
        LEFT: 'd4',
        RIGHT: 'd6',
    },
    'd6': {
        TILE_NAME: dirt_path_name,
        DESCRIPTION: dirt_path_describe_1,
        EXAMINATION: dirt_path_examine_1,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'c6',
        DOWN: 'e6',
        LEFT: 'd5',
        RIGHT: 'd7',
    }, 
    'd7': {
        TILE_NAME: wall_name,
        DESCRIPTION: stone_wall_describe,
        EXAMINATION: stone_wall_examine,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'c7',
        DOWN: 'e7',
        LEFT: 'd6',
        RIGHT: 'd8',
    },
    'd8': {
        TILE_NAME: dirt_path_name,
        DESCRIPTION: dirt_path_describe_1,
        EXAMINATION: dirt_path_examine_1,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'c8',
        DOWN: 'e8',
        LEFT: 'd7',
        RIGHT: 'd9',
    },
    'd9': {
        TILE_NAME: dirt_path_name,
        DESCRIPTION: dirt_path_describe_1,
        EXAMINATION: dirt_path_examine_1,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'c9',
        DOWN: 'e9',
        LEFT: 'd8',
        RIGHT: 'd10',
    },
    'd10': {
        TILE_NAME: dirt_path_name,
        DESCRIPTION: dirt_path_describe_1,
        EXAMINATION: dirt_path_examine_1,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'c10',
        DOWN: 'e10',
        LEFT: 'd9',
        RIGHT: 'd11',
    },
    'd11': {
        TILE_NAME: wall_name,
        DESCRIPTION: stone_wall_describe,
        EXAMINATION: stone_wall_examine,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'c11',
        DOWN: 'e11',
        LEFT: 'd10',
        RIGHT: 'd12',
    },
    'd12': {
        TILE_NAME: wall_name,
        DESCRIPTION: stone_wall_describe,
        EXAMINATION: stone_wall_examine,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'c12',
        DOWN: '',
        LEFT: 'd11',
        RIGHT: '',
    },
    'e1': {
        TILE_NAME: wall_name,
        DESCRIPTION: stone_wall_describe,
        EXAMINATION: stone_wall_examine,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'd1',
        DOWN: 'f1',
        LEFT: '',
        RIGHT: 'e2',
    },
    'e2': {
        TILE_NAME: "Dirty Key",
        DESCRIPTION: "A dirty key hanging on a rusty hook.",
        EXAMINATION: "The key is dirty.",
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'd2',
        DOWN: 'f2',
        LEFT: 'e1',
        RIGHT: 'e3',
    },
    'e3': {
        TILE_NAME: dirt_path_name,
        DESCRIPTION: dirt_path_describe_1,
        EXAMINATION: dirt_path_examine_1,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'd3',
        DOWN: 'f3',
        LEFT: 'e2',
        RIGHT: 'e4',
    },
    'e4': {
        TILE_NAME: wall_name,
        DESCRIPTION: stone_wall_describe,
        EXAMINATION: stone_wall_examine,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'd4',
        DOWN: 'f4',
        LEFT: 'e3',
        RIGHT: 'e5',
    },
    'e5': {
        TILE_NAME: wall_name,
        DESCRIPTION: stone_wall_describe,
        EXAMINATION: stone_wall_examine,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'd5',
        DOWN: 'f5',
        LEFT: 'e4',
        RIGHT: 'e6',
    },
    'e6': {
        TILE_NAME: dirt_path_name,
        DESCRIPTION: dirt_path_describe_1,
        EXAMINATION: dirt_path_examine_1,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'd6',
        DOWN: 'f6',
        LEFT: 'e5',
        RIGHT: 'e7',
    },
    'e7': {
        TILE_NAME: wall_name,
        DESCRIPTION: stone_wall_describe,
        EXAMINATION: stone_wall_examine,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'd7',
        DOWN: 'f7',
        LEFT: 'e6',
        RIGHT: 'e8',
    },
    'e8': {
        TILE_NAME: dirt_path_name,
        DESCRIPTION: dirt_path_describe_1,
        EXAMINATION: dirt_path_examine_1,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'd8',
        DOWN: 'f8',
        LEFT: 'e7',
        RIGHT: 'e9',
    },
    'e9': {
        TILE_NAME: wall_name,
        DESCRIPTION: stone_wall_describe,
        EXAMINATION: stone_wall_examine,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'd9',
        DOWN: 'f9',
        LEFT: 'e8',
        RIGHT: 'e10',
    },
    'e10': {
        TILE_NAME: wall_name,
        DESCRIPTION: stone_wall_describe,
        EXAMINATION: stone_wall_examine,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'd10',
        DOWN: 'f10',
        LEFT: 'd9',
        RIGHT: 'd11',
    },
    'e11': {
        TILE_NAME: wall_name,
        DESCRIPTION: stone_wall_describe,
        EXAMINATION: stone_wall_examine,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'd11',
        DOWN: 'f11',
        LEFT: 'e10',
        RIGHT: '',
    },
    'f1': {
        TILE_NAME: wall_name,
        DESCRIPTION: stone_wall_describe,
        EXAMINATION: stone_wall_examine,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'e1',
        DOWN: '',
        LEFT: '',
        RIGHT: 'f2',
    },
    'f2': {
        TILE_NAME: wall_name,
        DESCRIPTION: stone_wall_describe,
        EXAMINATION: stone_wall_examine,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'e2',
        DOWN: '',
        LEFT: 'f1',
        RIGHT: 'f3',
    },
    'f3': {
        TILE_NAME: wall_name,
        DESCRIPTION: stone_wall_describe,
        EXAMINATION: stone_wall_examine,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'e3',
        DOWN: '',
        LEFT: 'f2',
        RIGHT: 'f4',
    },
    'f4': {
        TILE_NAME: wall_name,
        DESCRIPTION: stone_wall_describe,
        EXAMINATION: stone_wall_examine,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'e4',
        DOWN: '',
        LEFT: 'f3',
        RIGHT: 'f5',
    },
    'f5': {
        TILE_NAME: wall_name,
        DESCRIPTION: stone_wall_describe,
        EXAMINATION: stone_wall_examine,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'e5',
        DOWN: 'g5',
        LEFT: 'f4',
        RIGHT: 'f6',
    },
    'f6': {
        TILE_NAME: dirt_path_name,
        DESCRIPTION: dirt_path_describe_1,
        EXAMINATION: dirt_path_examine_1,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'e6',
        DOWN: 'g6',
        LEFT: 'f5',
        RIGHT: 'f7',
    },
    'f7': {
        TILE_NAME: dirt_path_name,
        DESCRIPTION: dirt_path_describe_1,
        EXAMINATION: dirt_path_examine_1,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'e7',
        DOWN: 'e7',
        LEFT: 'f6',
        RIGHT: 'f8',
    },
    'f8': {
        TILE_NAME: dirt_path_name,
        DESCRIPTION: dirt_path_describe_1,
        EXAMINATION: dirt_path_examine_1,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'e8',
        DOWN: 'g8',
        LEFT: 'f7',
        RIGHT: 'f9',
    },
    'f9': {
        TILE_NAME: dirt_path_name,
        DESCRIPTION: dirt_path_describe_1,
        EXAMINATION: dirt_path_examine_1,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'e9',
        DOWN: 'g9',
        LEFT: 'f8',
        RIGHT: 'f10',
    },
    'f10': {
        TILE_NAME: dirt_path_name,
        DESCRIPTION: dirt_path_describe_1,
        EXAMINATION: dirt_path_examine_1,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'e10',
        DOWN: 'g10',
        LEFT: 'f9',
        RIGHT: 'f11',
    },
    'f11': {
        TILE_NAME: wall_name,
        DESCRIPTION: stone_wall_describe,
        EXAMINATION: stone_wall_examine,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'e11',
        DOWN: 'g11',
        LEFT: 'f10',
        RIGHT: '',
    },
    'g5': {
        TILE_NAME: wall_name,
        DESCRIPTION: stone_wall_describe,
        EXAMINATION: stone_wall_examine,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'f5',
        DOWN: '',
        LEFT: '',
        RIGHT: 'g6',
    },
    'g6': {
        TILE_NAME: wall_name,
        DESCRIPTION: stone_wall_describe,
        EXAMINATION: stone_wall_examine,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'f6',
        DOWN: '',
        LEFT: 'g5',
        RIGHT: 'g7',
    },
    'g7': {
        TILE_NAME: wall_name,
        DESCRIPTION: stone_wall_describe,
        EXAMINATION: stone_wall_examine,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'f7',
        DOWN: '',
        LEFT: 'g6',
        RIGHT: 'g8',
    },
    'g8': {
        TILE_NAME: wall_name,
        DESCRIPTION: stone_wall_describe,
        EXAMINATION: stone_wall_examine,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'f8',
        DOWN: '',
        LEFT: 'g7',
        RIGHT: 'g9',
    },
    'g9': {
        TILE_NAME: wall_name,
        DESCRIPTION: stone_wall_describe,
        EXAMINATION: stone_wall_examine,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'f9',
        DOWN: 'h9',
        LEFT: 'g8',
        RIGHT: 'g10',
    },
    'g10': {
        TILE_NAME: dirt_path_name,
        DESCRIPTION: dirt_path_describe_1,
        EXAMINATION: dirt_path_examine_1,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'f10',
        DOWN: 'h10',
        LEFT: 'g9',
        RIGHT: 'g11',
    },
    'g11': {
        TILE_NAME: wall_name,
        DESCRIPTION: stone_wall_describe,
        EXAMINATION: stone_wall_examine,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'f11',
        DOWN: 'h11',
        LEFT: 'g10',
        RIGHT: '',
    },
    'h9': {
        TILE_NAME: wall_name,
        DESCRIPTION: stone_wall_describe,
        EXAMINATION: stone_wall_examine,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'g9',
        DOWN: '',
        LEFT: '',
        RIGHT: 'g10',
    },
    'h10': {
        TILE_NAME: 'Chamber Door',
        DESCRIPTION: stone_wall_describe,
        EXAMINATION: stone_wall_examine,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'g10',
        DOWN: '',
        LEFT: 'h9',
        RIGHT: 'h11',
    },
    'h11': {
        TILE_NAME: wall_name,
        DESCRIPTION: stone_wall_describe,
        EXAMINATION: stone_wall_examine,
        DOOR: 'none',
        COMPLETED_TEXT: '',
        UP: 'f11',
        DOWN: '',
        LEFT: 'h10',
        RIGHT: '',
    },
}


mush_checkpoints = {
    'mush intro': False,
    'tunnel entered': False,
    'door found': False,
    'door opened': False
}

mushrooms_defeated = {
    'd3': False,
    'c10': False,
    'g10': False
    
}


def mush_intro(player):

    """

        The player fights a mushroom guard and 
        discoveres tunnel to the mushroom lair.

    """

    text_display(mush_text[2],.05)
    text_display(mush_text[5],.05)
    text_display(mush_text[8],.05)
    enter()
    fight_image(player, mushroom_guard)
    text_display(mush_text[11],.05)
    print()
    text_display(mush_text[14],.05)

    print()
    choice = ""
    while choice not in accept and choice not in decline:
        choice = input(" > ").lower().strip()

    if choice in accept: 
        player.active_quests += "MushroomMania"
        player.current_map = mush_map
        mush_checkpoints['mush intro'] = True
        mush_checkpoints['tunnel entered'] = True
        player.quest_location = 'd6'


def mush_king(player):
    print("A deep voice rumbles through the tunnels:")
    print("\n'You may pass.'\n")
    print("The door slowly slides down into the ground, as if becoming part of it.")


def door_puzzle(player):

    """

        Displays the door information and presents
        the player with a riddle/puzzle.

    """

    print("\n\n\n")
    text_display(mush_text[30],.03)
    text_display(mush_text[33],.03)
    print("\n\n")
    text_display(mush_text[36],.05)
    print("\n\n")
    text_display(mush_text[39],.05)
    print("\n\n")
    text_display(mush_text[42],.05)
    print("\n\n\n.................................")
    print("Would you like to press a button?")

    choice = ''
    acceptable_actions = accept + decline
    while choice not in acceptable_actions:
        choice = input(" > ").lower().strip()

    if choice in decline:
        player.quest_location = 'f10'
        text_display("\nYou walk away from the door.\n", .03)
        time.sleep(2)
    elif choice in accept:
        print("\n.....................................")
        text_display("Which button would you like to press?\n", .03)

        choice = ''
        acceptable_options  = ['1', '2', '3', '4', '5']
        while choice not in acceptable_options: 
            choice = input(" > ").lower().strip()

        if choice == '1':
            health_loss = player.maxhp*.1
            player.hp -= health_loss
            print("One of the faces releases poison gas!")
            print(" - %d HP\n" % health_loss)
        elif choice == '2':
            mush_king(player)
        elif choice == '3':
            health_loss = player.maxhp*.1
            player.hp -= health_loss
            print("One of the faces releases poison gas!")
            print(" - %d HP\n" % health_loss)
        elif choice == '4':
            health_loss = player.maxhp*.1
            player.hp -= health_loss
            print("One of the faces releases poison gas!")
            print(" - %d HP\n" % health_loss)
        elif choice == '5':
            health_loss = player.maxhp*.1
            player.hp -= health_loss
            print("One of the faces releases poison gas!")
            print(" - %d HP\n" % health_loss)



def mushroom_mania(player):
    
    """

        Calls the necessary functions in order for the 
        Mushroom Mania quest to be complete.

    """

    if mush_checkpoints['mush intro'] == False: 
        print(mushrooms_defeated)
        mush_intro(player)
    elif mush_checkpoints['tunnel entered'] == False: 
        text_display(mush_text[14],.05)
        choice = ""
        while choice not in accept and choice not in decline:
            choice = input(" > ").lower().strip()

        if choice in accept: 
            mush_checkpoints['tunnel entered'] = True
            player.current_map = mush_map
            player.quest_location = 'd6'


    if "MushroomMania" not in player.completed_quests and mush_checkpoints['tunnel entered'] == True:  

        if player.quest_location == 'd5':
            choice = ''
            print("Would you like to leave the tunnel?")
            while choice not in accept and choice not in decline:
                choice = input(" > ").lower().strip()

            if choice in accept:
                mush_checkpoints['tunnel entered'] == False
                player.current_map = world_map
            else: player.quest_location = 'd6'


        if player.quest_location == 'd3' and mushrooms_defeated['d3'] == False:
            fight_image(player, mushroom_guard)
            mushrooms_defeated['d3'] = True

        if player.quest_location == 'c10' and mushrooms_defeated['c10'] == False:
            fight_image(player, mushroom_guard)
            mushrooms_defeated['c10'] = True

        if player.quest_location == 'g10' and mushrooms_defeated['g10'] == False:
            print("As you round the corner, you see a much larger mushroom standing in front of you!")
            fight_image(player, big_mushroom_guard)
            mushrooms_defeated['g10'] = True
        
        if player.quest_location == 'g10':
            door_puzzle(player)

        if player.quest_location == 'g10' and mush_checkpoints['door opened'] == True:
            mush_wrapup(player)




