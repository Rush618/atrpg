#####################################
#         Another Text RPG          #
#         By: Rush Deeter           #
# In Collaboration With: Kathy Orta #



"""


This file contains the prompt functions
and some fo its sub-functions. The code
included is:

Functions:
    - quest_prompt
    - quest_examine
    - quest_help_menu


"""



from WorldMapFile import *
from Utility import enter,text_display,quit_game
from .QuestMovement import quest_movement,quest_movement_handler,quest_location
from AcceptableLists import quitting,moving,inspecting,helping,locating,quick_move
from Locating import new_mapping



def quest_prompt(player, quest_map):
    
    """

        The prompt for quests. While the 
        player is located on the quest map, they
        are prompted to input a valid command. 
        Based on the player's input, various other
        functions are called.

    """
    
    print("\n" + "..........................")
    print("What would you like to do?")
    action = ''
    acceptable_actions = quitting+moving+inspecting+helping+locating+quick_move
    while action not in acceptable_actions:
        action = input(' > ').lower()
    if action in quitting:
        quit_game(quest_prompt,player,quest_map)
    elif action in moving:
        quest_movement('',player,action,quest_map)    
    elif action in quick_move:
        action_list = action.split()
        quest_movement(action_list[1],player,action_list[0],quest_map)
    elif action in inspecting:
        quest_examine(player, quest_map) 
    elif action in locating:
        new_mapping(player.quest_location,quest_map)
    elif action in helping:
        quest_help_menu()    
        

def quest_examine(player, quest_map):
    
    """

        Displays the 'examination' text for the tile the 
        player is currently on.

    """

    examine_text = quest_map[player.quest_location][EXAMINATION]
    text_display(examine_text,.03)


def quest_help_menu():
    
    """

        Displays the help menu for the 'quest prompt' function.
        Eventually, this will show a list of valid commands
        that the player has already discovered.

    """

    print(".........................................")
    print("                Help Menu                ")
    print(".........................................")
    print(" Explanation of the game and its basic   ")
    print(" controls (fighting, moving, examining,  ")
    print(" etc)                                    ")
    print(".........................................")
    enter()