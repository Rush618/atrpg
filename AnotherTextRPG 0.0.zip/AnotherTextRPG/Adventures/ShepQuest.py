#####################################
#         Another Text RPG          #
#         By: Rush Deeter           #
# In Collaboration With: Kathy Orta #



"""


This file lays out the first quest
in the game. Here the player's name and
job (class) are decided. The files
included are:

Dictionaries:
    - shep_map
    - shep_checkpoints

Functions:
    - shep intro
    - finding_sheep
    - shep_wrapup
    - shepherd_quest


"""



import os
import time

#from Prompting import prompt
from Looting import gold_gain
from WorldMapFile import world_map
from Utility import enter,text_display,stat_display
#from .QuestPrompting import quest_prompt
from AcceptableLists import accept,decline
from Equipment.Spells import fireslap,wimpyheal
from Equipment.Weapons import dull_iron_ss,dull_iron_dagger
from MapPhrases import *



shep_text = []
with open("Adventures/ShepQuestText.txt", "r") as myfile:
    for lines in myfile:
        shep_text.append(lines)

shep_lore = []
with open("Story/ShepLore.txt", "r") as myfile:
    for lines in myfile:
        shep_lore.append(lines)


TILE_NAME = 'name'
DESCRIPTION = 'describe'
EXAMINATION = 'examine'        
SHEEP = 'none'
COMPLETED_TEXT = 'area complete'
UP = 'up', 'north'
DOWN = 'down', 'south'
LEFT = 'left', 'west'
RIGHT = 'right', 'east'


shep_map = {
    'z0': {
        TILE_NAME: wall_name,
        DESCRIPTION: wood_wall_describe,
        EXAMINATION: wood_wall_examine,
        SHEEP: 'none',
        COMPLETED_TEXT: '',
        UP: '',
        DOWN: 'a0',
        LEFT: '',
        RIGHT: 'z1',
    },
    'z1': {
        TILE_NAME: wall_name,
        DESCRIPTION: wood_wall_describe,
        EXAMINATION: wood_wall_examine,
        SHEEP: 'none',
        COMPLETED_TEXT: '',
        UP: '',
        DOWN: 'a1',
        LEFT: '',
        RIGHT: 'z2',
    },
    'z2': {
        TILE_NAME: wall_name,
        DESCRIPTION: wood_wall_describe,
        EXAMINATION: wood_wall_examine,
        SHEEP: 'none',
        COMPLETED_TEXT: '',
        UP: '',
        DOWN: 'a2',
        LEFT: 'z1',
        RIGHT: 'z3',
    },
    'z3': {
        TILE_NAME: wall_name,
        DESCRIPTION: wood_wall_describe,
        EXAMINATION: wood_wall_examine,
        SHEEP: 'none',
        COMPLETED_TEXT: '',
        UP: '',
        DOWN: 'a3',
        LEFT: 'z2',
        RIGHT: 'z4',
    },
    'z4': {
        TILE_NAME: wall_name,
        DESCRIPTION: wood_wall_describe,
        EXAMINATION: wood_wall_examine,
        SHEEP: 'none',
        COMPLETED_TEXT: '',
        UP: '',
        DOWN: 'a4',
        LEFT: 'z3',
        RIGHT: 'z5',
    },
    'z5': {
        TILE_NAME: river_name,
        DESCRIPTION: river_describe,
        EXAMINATION: river_examine,
        SHEEP: 'none',
        COMPLETED_TEXT: '',
        UP: '',
        DOWN: 'a4',
        LEFT: 'z4',
        RIGHT: '',
    },
    'a0': {
        TILE_NAME: wall_name,
        DESCRIPTION: wood_wall_describe,
        EXAMINATION: wood_wall_examine,
        SHEEP: 'none',
        COMPLETED_TEXT: '',
        UP: 'z0',
        DOWN: 'b0',
        LEFT: '',
        RIGHT: 'a1',
    },
    'a1': {
        TILE_NAME: trees_name,
        DESCRIPTION: trees_describe_1,
        EXAMINATION: trees_examine_1,
        SHEEP: 'none',
        COMPLETED_TEXT: '',
        UP: 'z1',
        DOWN: 'b1',
        LEFT: 'a0',
        RIGHT: 'a2',
    },
    'a2': {
        TILE_NAME: trees_name,
        DESCRIPTION: trees_describe_1,
        EXAMINATION: trees_examine_1,
        SHEEP: 'none',
        COMPLETED_TEXT: '',
        UP: 'z2',
        DOWN: 'b2',
        LEFT: 'a1',
        RIGHT: 'a3',
    },   
    'a3': {
        TILE_NAME: grass_name,
        DESCRIPTION: grass_describe_1,
        EXAMINATION: grass_examine_1,
        SHEEP: 'none',
        COMPLETED_TEXT: '',
        UP: 'z3',
        DOWN: 'b3',
        LEFT: 'a2',
        RIGHT: 'a4',
    }, 
    'a4': {
        TILE_NAME: grass_name,
        DESCRIPTION: grass_describe_1,
        EXAMINATION: grass_examine_1,
        SHEEP: 'none',
        COMPLETED_TEXT: '',
        UP: 'z4',
        DOWN: 'b4',
        LEFT: 'a3',
        RIGHT: 'River',
    }, 
    'a5': {
        TILE_NAME: river_name,
        DESCRIPTION: river_describe,
        EXAMINATION: river_examine,
        SHEEP: 'none',
        COMPLETED_TEXT: '',
        UP: 'z4',
        DOWN: 'b4',
        LEFT: 'a3',
        RIGHT: '',
    },
    'b0': {
        TILE_NAME: wall_name,
        DESCRIPTION: wood_wall_describe,
        EXAMINATION: wood_wall_examine,
        SHEEP: 'none',
        COMPLETED_TEXT: '',
        UP: 'a0',
        DOWN: 'c0',
        LEFT: '',
        RIGHT: 'b1',
    },
    'b1': {
        TILE_NAME: trees_name,
        DESCRIPTION: trees_describe_1,
        EXAMINATION: trees_examine_1,
        SHEEP: 'none',
        COMPLETED_TEXT: '',
        UP: 'a1',
        DOWN: 'c1',
        LEFT: 'b0',
        RIGHT: 'b2',
    },
    'b2': {
        TILE_NAME: 'The Shepherd',
        DESCRIPTION: 'You are surrounded by trees and see open fields to the south and east.',
        EXAMINATION: "You don't see much out of the ordinary, but to the southeast\n you hear the sound of bleating lambs...'baaa' 'baaaa'",
        SHEEP: 'none',
        COMPLETED_TEXT: 'This is where you first awoke and met the shepherd.',
        UP: 'a2',
        DOWN: 'c2',
        LEFT: 'b1',
        RIGHT: 'b3',
    },   
    'b3': {
        TILE_NAME: grass_name,
        DESCRIPTION: grass_describe_1,
        EXAMINATION: 'You hear sheep to the south',
        SHEEP: 'none',
        COMPLETED_TEXT: 'Its all quiet except for the sound of tree branches creaking in the wind.',
        UP: 'a3',
        DOWN: 'c3',
        LEFT: 'b2',
        RIGHT: 'b4',
    }, 
    'b4': {
        TILE_NAME: grass_name,
        DESCRIPTION: grass_describe_1,
        EXAMINATION: 'You hear sheep to the south-west',
        SHEEP: 'none',
        COMPLETED_TEXT: 'Its all quiet except for the sound of wind rustling the grass.',
        UP: 'a4',
        DOWN: 'c4',
        LEFT: 'b3',
        RIGHT: 'b5',
    },
    'b5': {
        TILE_NAME: river_name,
        DESCRIPTION: river_describe,
        EXAMINATION: river_examine,
        SHEEP: 'none',
        COMPLETED_TEXT: 'Its all quiet except for the sound of wind rustling the grass.',
        UP: 'a5',
        DOWN: 'c5',
        LEFT: 'b4',
        RIGHT: '',
    },
    'c0': {
        TILE_NAME: 'Wall',
        DESCRIPTION: '',
        EXAMINATION: '',
        SHEEP: 'none',
        COMPLETED_TEXT: '',
        UP: 'b0',
        DOWN: 'd0',
        LEFT: '',
        RIGHT: 'c1',
    },
    'c1': {
        TILE_NAME: trees_name,
        DESCRIPTION: trees_describe_1,
        EXAMINATION: trees_examine_1,
        SHEEP: 'none',
        COMPLETED_TEXT: '',
        UP: 'b1',
        DOWN: 'd1',
        LEFT: 'c0',
        RIGHT: 'c2',
    },
    'c2': {
        TILE_NAME: grass_name,
        DESCRIPTION: grass_describe_1,
        EXAMINATION: 'You hear sheep to the east',
        SHEEP: 'none',
        COMPLETED_TEXT: 'All Quiet on the Western Front',
        UP: 'b2',
        DOWN: 'd2',
        LEFT: 'c1',
        RIGHT: 'c3',
    },   
    'c3': {
        TILE_NAME: grass_name,
        DESCRIPTION: grass_describe_1,
        EXAMINATION: "This is where you found the sheep!",
        SHEEP: 'sheep',
        COMPLETED_TEXT: 'This is where you found the sheep!',
        UP: 'b3',
        DOWN: 'd3',
        LEFT: 'c2',
        RIGHT: 'c4',
    }, 
    'c4': {
        TILE_NAME: grass_name,
        DESCRIPTION: grass_describe_1,
        EXAMINATION: 'You hear sheep to the west',
        SHEEP: 'none',
        COMPLETED_TEXT: '',
        UP: 'b4',
        DOWN: 'd4',
        LEFT: 'c3',
        RIGHT: 'c5',
    },
    'c5': {
        TILE_NAME: river_name,
        DESCRIPTION: river_describe,
        EXAMINATION: river_examine,
        SHEEP: 'none',
        COMPLETED_TEXT: '',
        UP: 'b5',
        DOWN: 'd5',
        LEFT: 'c4',
        RIGHT: '',
    },
    'd0': {
        TILE_NAME: wall_name,
        DESCRIPTION: wood_wall_describe,
        EXAMINATION: wood_wall_examine,
        SHEEP: 'none',
        COMPLETED_TEXT: '',
        UP: 'c0',
        DOWN: 'e0',
        LEFT: '',
        RIGHT: 'd1',
    },
    'd1': {
        TILE_NAME: grass_name,
        DESCRIPTION: grass_describe_1,
        EXAMINATION: grass_examine_1,
        SHEEP: 'none',
        COMPLETED_TEXT: '',
        UP: 'c1',
        DOWN: 'e1',
        LEFT: 'd0',
        RIGHT: 'd2',
    },
    'd2': {
        TILE_NAME: grass_name,
        DESCRIPTION: grass_describe_1,
        EXAMINATION: 'You hear sheep to the north-east',
        SHEEP: 'none',
        COMPLETED_TEXT: '',
        UP: 'c2',
        DOWN: 'e2',
        LEFT: 'd1',
        RIGHT: 'd3',
    },   
    'd3': {
        TILE_NAME: grass_name,
        DESCRIPTION: grass_describe_1,
        EXAMINATION: 'You hear sheep to the north',
        SHEEP: 'none',
        COMPLETED_TEXT: '',
        UP: 'c3',
        DOWN: 'e3',
        LEFT: 'd2',
        RIGHT: 'd4',
    }, 
    'd4': {
        TILE_NAME: grass_name,
        DESCRIPTION: grass_describe_1,
        EXAMINATION: 'You hear sheep to the north-west',
        SHEEP: 'none',
        COMPLETED_TEXT: '',
        UP: 'c4',
        DOWN: 'e4',
        LEFT: 'd3',
        RIGHT: 'd5',
    },
    'd5': {
        TILE_NAME: river_name,
        DESCRIPTION: river_describe,
        EXAMINATION: river_examine,
        SHEEP: 'none',
        COMPLETED_TEXT: '',
        UP: 'c5',
        DOWN: 'e5',
        LEFT: 'd4',
        RIGHT: '',
    },
    'e0': {
        TILE_NAME: river_name,
        DESCRIPTION: river_describe,
        EXAMINATION: river_examine,
        SHEEP: 'none',
        COMPLETED_TEXT: '',
        UP: 'd0',
        DOWN: '',
        LEFT: '',
        RIGHT: 'e1',
    },
    'e1': {
        TILE_NAME: river_name,
        DESCRIPTION: river_describe,
        EXAMINATION: river_examine,
        SHEEP: 'none',
        COMPLETED_TEXT: '',
        UP: 'd1',
        DOWN: '',
        LEFT: 'e0',
        RIGHT: 'e2',
    },
    'e2': {
        TILE_NAME: river_name,
        DESCRIPTION: river_describe,
        EXAMINATION: river_examine,
        SHEEP: 'none',
        COMPLETED_TEXT: '',
        UP: 'd2',
        DOWN: '',
        LEFT: 'e1',
        RIGHT: 'e3',
    },
    'e3': {
        TILE_NAME: river_name,
        DESCRIPTION: river_describe,
        EXAMINATION: river_examine,
        SHEEP: 'none',
        COMPLETED_TEXT: '',
        UP: 'd3',
        DOWN: '',
        LEFT: 'e2',
        RIGHT: 'e4',
    },
    'e4': {
        TILE_NAME: river_name,
        DESCRIPTION: river_describe,
        EXAMINATION: river_examine,
        SHEEP: 'none',
        COMPLETED_TEXT: '',
        UP: 'd4',
        DOWN: '',
        LEFT: 'e3',
        RIGHT: 'e5',
    },
    'e5': {
        TILE_NAME: river_name,
        DESCRIPTION: river_describe,
        EXAMINATION: river_examine,
        SHEEP: 'none',
        COMPLETED_TEXT: '',
        UP: 'd5',
        DOWN: '',
        LEFT: 'e4',
        RIGHT: '',
    },
}


shep_checkpoints = {
    'shep intro': False,
    'quest accepted': False,
    'sheep found': False,
}




def job_assignmet(player):
    
    shep_checkpoints['quest accepted'] = False
    print()
    job_options = ['warrior','mage','rogue']
    print("Options: ")
    print(job_options)
    while player.job not in job_options:
        player.job = input(" > ").lower().strip()

    if player.job == 'warrior':

        print("'Wow, a warrior! I haven't seen the likes of you...well ever!'")
        print("'Alright well it was a pleasure meeting you, and thanks again for the help!'")
        print("'The shepherd walk away from you with a pep in his step.'")
        

        player.DEX = 7
        player.INT = 5
        player.STR = 10

        player.maxhp = 35
        player.hp = 35
        player.maxmp = 15
        player.mp = 15

        player.weapon_equipped = dull_iron_ss

        player.healing_spells_known += [wimpyheal]

        time.sleep(2)
        os.system("cls")
        enter()
        print("Would you like an explanation of the warrior's features?\n")

        choice  = ""
        while choice not in accept and choice not in decline:
            choice  = input(" > ").lower().strip()

        os.system("cls")            
        if choice in accept:

            stat_display(player)
            
            print("Dexterity effects your ability to dodge and counter attacks.")
            print("Intelligence effects you total Mana and how much you regain during combat.")          
            print("As you increase your strength, you will do more melee damage.")
            enter()
            print("When you level up, you will get +1 INT, +2 DEX, and +3 STR.")
            print("Warriors also get +10 Health every level.")
            print("Levels coming soon...\n")

    if player.job == 'rogue':

        print("'Oh...well have a nice one, I guess...'")
        print("The shepherd walks away from you clutching his pockets and looking over his shoulder.")
    
        player.DEX = 10
        player.INT = 5
        player.STR = 7

        player.maxhp = 35
        player.hp = 35
        player.maxmp = 15
        player.mp = 15

        player.weapon_equipped = dull_iron_dagger

        player.healing_spells_known += [wimpyheal]

        time.sleep(2)
        os.system("cls")
        enter()
        print("Would you like an explanation of the rogue's features?\n")

        choice  = ""
        while choice not in accept and choice not in decline:
            choice  = input(" > ").lower().strip()

        os.system("cls")            
        if choice in accept:

            stat_display(player)
            
            print("Dexterity effects your ability to dodge and counter attacks.")
            print("Intelligence effects you total Mana and how much you regain during combat.")
            print("As you increase your strength, you will do more melee damage.")
            enter()
            print("When you level up, you will get +1 INT, +2 STR, and +3 DEX.")
            print("Rogues also get +7 Health every level.")
            print("Levels coming soon...\n")

    if player.job == 'mage':
        print("'Hm...do you know [wizard name here]? If not I'm sure he'd love to meet you. You can find him at [some place].'")
        print("The shepherd walks away, looking off to the distance thoughtfully.")

        player.DEX = 7
        player.INT = 10
        player.STR = 5

        player.maxhp = 25
        player.hp = 25
        player.maxmp = 25
        player.mp = 25

        player.healing_spells_known += [wimpyheal]
        player.damage_spells_known += [fireslap]

        time.sleep(2)
        os.system("cls")
        enter()
        print("Would you like an explanation of the mage's features?\n")

        choice  = ""
        while choice not in accept and choice not in decline:
            choice  = input(" > ").lower().strip()

        os.system("cls")            
        if choice in accept:

            stat_display(player)
            
            print("Dexterity effects your ability to dodge and counter attacks.")
            print("Intelligence effects you total Mana and how much you regain during combat.")
            print("As you increase your strength, you will do more melee damage.")
            enter()
            print("When you level up, you will get +1 STR, +2 DEX, and +3 INT.")
            print("Mages also get +5 Health every level.")
            print("Levels coming soon...\n")


def shep_intro(player):
    
    """

        The first interaction the player has with
        the world. Here, the player chooses their
        name and whether or not they want to 
        help the shepherd.

    """
    
    player.active_quests += "ShepQuest"

    text_display(shep_text[2],.05)
    text_display(shep_text[5],.03)
    text_display(shep_text[8],.03)
    text_display(shep_text[11],.05)
    print()
    while player.name == "":
        player.name = input(" > ")

    text_display("'It's a pleasure to meet you, " + player.name + ".'\n",.05)
    text_display(shep_text[17],.05)
    text_display(shep_text[20],.05)
    #text_display(shep_text[23],.05)
    text_display(shep_text[26],.03)
    shep_checkpoints['shep intro'] = True
    print()

    acceptable_responses = accept+decline
    shep_accept = ""
    while shep_accept not in acceptable_responses:
        shep_accept = input(" > ").lower()

    if shep_accept in accept:
        shep_checkpoints['quest accepted'] = True
        text_display(shep_text[32],.05)
        text_display(shep_text[35],.05)
        text_display(shep_text[38],.05)
    elif shep_accept in decline:  
        text_display(shep_text[65],.05)
        text_display(shep_text[68],.05)
        text_display(shep_text[71],.05)
        job_assignmet(player)


def finding_sheep(player):
    
    """

        Checks whether the player has moed to the 
        same tile as the sheep and describes what
        the player needs to do to continue the
        quest. This also changes the examine text
        for the tiles specified in 'list to change'.

    """
    
           
    text_display(shep_text[41],.03)
    text_display(shep_text[44],.03)
    shep_checkpoints['sheep found'] = True
    shep_map[player.quest_location][SHEEP]= 'none'
    list_to_change = ['b2','b3','b4','c2','c4','d2','d3','d4']
    for dict in list_to_change:
        shep_map[dict][EXAMINATION] = shep_map[dict][COMPLETED_TEXT]


def shep_wrapup(player):
    
    """

        Checks if the player has reached the
        shepherd after finding the sheep and
        rewards the player accordingly. Also 
        provides the 
          
    """
    
    text_display(shep_text[47],.05)
    text_display(shep_text[50],.05)
    text_display(shep_text[53],.05)
    text_display(shep_text[56],.05)
    print()
    gold_gain(50,player)
    player.completed_quests += "ShepQuest"

    enter()

    text_display(shep_text[59],.05)
     
    job_assignmet(player)

    #acceptable_responses = accept+decline
    #shep_accept = ""
    #while shep_accept not in acceptable_responses:
    #    shep_accept = input(" > ").lower()
    #if shep_accept in accept:
    #    text_display(shep_lore[9],.05)
    #    player.location = 'H6'
    #elif shep_accept in decline:
    #    text_display(shep_lore[3],.05)



def shepherd_quest(player):
    
    """

        Continues calling the 'quest prompt' function
        until the quest ends, at which time the player
        returns to the 'main game loop'. This is also 
        where the progression of the quest occurs.

    """

    player.current_map = shep_map

    if shep_checkpoints['shep intro'] == False: 
        shep_intro(player)

    if "ShepQuest" not in player.completed_quests and shep_checkpoints['quest accepted'] == True:   

        if player.quest_location == 'c3': 
            finding_sheep(player)
            print("Sheepies")

        if player.quest_location == 'b2' and "ShepQuest" not in player.completed_quests and shep_checkpoints['sheep found'] == True:
            shep_wrapup(player)
            player.current_map = world_map




