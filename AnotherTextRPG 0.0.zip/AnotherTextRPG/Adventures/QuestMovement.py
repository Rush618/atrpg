#####################################
#         Another Text RPG          #
#         By: Rush Deeter           #
# In Collaboration With: Kathy Orta #



"""


This file lays out the ability for
the player to move throught eh world.
The code included is:

Functions:
    - quest_location
    - quest_movement
    - quest_movement_handler


"""



import os
import sys
import cmd
import time 
from WorldMapFile import *
from Utility import enter,text_display
from AcceptableLists import directions,mistakes



def quest_location(player, quest_map):
    
    """

        Displays the player's current location
        on the Quest Map.

    """

    print('\n\n' + ('=' * (6 + len(quest_map[player.quest_location][TILE_NAME]))))
    print('   ' + quest_map[player.quest_location][TILE_NAME])
    #print('=' * (6 + len(quest_map[player.quest_location][TILE_NAME])))
    #if quest_map[player.quest_location][SOLVED] is False:
    #    print(' - ' + quest_map[player.quest_location][DESCRIPTION])


def quest_movement(direction, player, player_action, quest_map):
    
    """

        Prompts the player for a directional input and 
        calls the 'quest movement handler' to actually
        move the player on the Quest Map.

    """        
    
    #direction = ''
    valid_directions = directions+mistakes
    if direction not in valid_directions:
        print("Where would you like to " + player_action + "?")
        while direction not in valid_directions:
            direction = input(" > ").lower()
    if direction in ['up','north']:
        destination = quest_map[player.quest_location][UP]
        quest_movement_handler(destination, direction, player, player_action,quest_map)
    elif direction in ['down','south']:
        destination = quest_map[player.quest_location][DOWN]
        quest_movement_handler(destination, direction, player, player_action,quest_map)
    elif direction in ['left','west']:
        destination = quest_map[player.quest_location][LEFT]
        quest_movement_handler(destination, direction, player, player_action,quest_map)
    elif direction in ['right','east']:
        destination = quest_map[player.quest_location][RIGHT]
        quest_movement_handler(destination, direction, player, player_action,quest_map)
    elif direction in mistakes:
        pass


def quest_movement_handler(destination, direction, player, player_action, quest_map):
    
    """

        Determine's if the player is able to
        move in the selected direction and
        then moves the player or returns them
        to the 'quest prompt' function.

    """
    
    if quest_map[destination][TILE_NAME] in ['Wall', 'River']:    
        if quest_map[destination][TILE_NAME] == 'Wall':
            text_display("There's a wall there.",.02)
        elif quest_map[destination][TILE_NAME] == 'River':
            text_display("This river is uncrossable.",.02)
    elif destination in quest_map: 
        player.quest_location = destination
        text_display("You " + player_action + " " + direction + ".",.02)
        quest_location(player, quest_map)
    else: text_display("\nYou can't go there.\n",.02)


