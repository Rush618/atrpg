#####################################
#         Another Text RPG          #
#         By: Rush Deeter           #
# In Collaboration With: Kathy Orta #



"""

This function creates the enemies of the game,
from humans to mushrooms and everything in between.
The code that makes these bad guys up is:




"""



from Equipment.Armor import *
from Equipment.Weapons import *


class Mushroom:
    def __init__(self, name, main_style, armor_equipped, weapon_equipped, item_types, armor, weapons, maxhp, hp, DEX, INT, STR, experience_reward, gp):
        
        self.name = name
        self.main_style = main_style

        self.armor_equipped = armor_equipped
        self.weapon_equipped = weapon_equipped

        self.item_types = item_types
        self.armor = armor
        self.weapons= weapons

        self.maxhp = maxhp
        self.hp = hp

        self.DEX = DEX
        self.INT = INT
        self.STR = STR

        self.experience_reward = experience_reward
        self.gp = gp

############ (name, main_style, armor_equipped, weapon_equipped, item_types, armor, weapons, maxhp, hp, DEX, INT, STR, experience_reward, gp)
mushroom_guard = Mushroom("Mushroom Guard", "melee", fungus_stalk, fungus_foot, ["no loot"], [], [], 10, 10, 5, 1, 2, 10, 3)
big_mushroom_guard = Mushroom("Big Mushroom Guard", "melee", fungus_stalk, fungus_foot, ["no loot"], [], [], 17, 17, 7, 1, 5, 20, 7)
king_mushroom = Mushroom("King Mushroom", "melee", fungus_stalk, fungus_foot, ["no loot"], [], [], 25, 25, 7, 1, 10, 30, 0)




