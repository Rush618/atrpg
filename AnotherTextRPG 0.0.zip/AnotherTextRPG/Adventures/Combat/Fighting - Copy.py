#####################################
#         Another Text RPG          #
#         By: Rush Deeter           #
# In Collaboration With: Kathy Orta #



"""

This function handles the game's combat.
The files which make this possible are:




"""



from Equipment.Armor import *
from Equipment.Weapons import *
from Equipment.Spells import *
from Equipment.Potions import *
from AcceptableLists import helping,weapon_key,potion_key,back
from .Enemies import *
from Looting import gold_gain,looting_options,item_display
from Utility import enter,text_display
from random import randint
import os
import time



def dodging(winner, loser):

    """

        Determines whether the winner of the 
        'deciding' roll dodges. if nobody doges,
        there is no chance of a counter.

    """

    dodge = ""

    loser_dodge_roll = randint(1,round(1.5 * loser.DEX))
    winner_dodge_roll = randint(1,winner.DEX)

    if winner_dodge_roll > loser_dodge_roll:
        dodge = "success"

    return dodge


def deciding(player, enemy):

    """

        Determines whether anyone has a chance to dodge.

    """

    dodger = ""

    player_decider_roll = randint(1,player.DEX)
    enemy_decider_roll = randint(1,enemy.DEX)

    if enemy_decider_roll > player_decider_roll:
        dodge = dodging(enemy, player)
        if dodge == "success":
            dodger = "enemy"
        else: dodger = ""

    elif enemy_decider_roll < player_decider_roll:
        dodge = dodging(player, enemy)
        if dodge == "success":
            dodger = "player"
        else: dodger = ""

    return dodger


def countering(winner, loser):

    """

        Determines whether teh winner of "dodging" 
        counters the loser's attack.

    """

    counter = ""

    loser_counter_roll = randint(1,round(2 * loser.DEX))
    winner_counter_roll = randint(1,winner.DEX)

    if winner_counter_roll > loser_counter_roll:
        counter = "success"

    return counter


def attribute_bonus(combatant, attribute):

    """

        Determines the damage increase
        for attack rolls based on the
        appropriate attribute.

    """

    count = 0
    bonus = 0
    for number in range(attribute):
        if count <= 2:
            bonus += 1
            count += 1
        elif count <= 4:
            bonus += .75
            count += 1
        elif count <= 8:
            bonus += .5
            count += 1
        elif count <= 16:
            bonus += .4
            count += 1
        elif count <= 32:
            bonus += .3
            count += 1
        elif count <= 64:
            bonus += .25
            count += 1

    true_bonus = int(bonus)
    return true_bonus


def melee_damage(attacker, defender):

    """

        Determines the amount of damage dealt
        by the attacker's martial weapon.

    """

    weapon_damage = randint(attacker.weapon_equipped.min_dmg, attacker.weapon_equipped.max_dmg)
    attr_bonus = attribute_bonus(attacker, attacker.STR)
    attacker_damage = weapon_damage + attr_bonus
    total_damage = attacker_damage - defender.armor_equipped.defense
    if total_damage < 0:
        total_damage = 0

    return total_damage


def magic_damage(attacker, defender, spell):

    """

        Rolls the damage a magic spell deals.

    """

    spell_damage = randint(0, spell.max_dmg)

    attr_bonus = attribute_bonus(attacker, attacker.INT)

    attacker_damage = spell_damage + attr_bonus
    total_damage = attacker_damage - round(defender.armor_equipped.defense * .9)

    if total_damage < 0:
        total_damage = 0
    return total_damage


def healing(player, heal_amount):

    """

        Provides the ability for the player
        to heal through spells and potions.

    """

    if player.hp + heal_amount >= player.maxhp:
        player.hp = player.maxhp
    else: player.hp += heal_amount

    print("\n<3 <3 <3 <3 <3 <3 ")
    print("        + %d HP" % heal_amount)
    print("  Health: %d" % player.hp)
    print("<3 <3 <3 <3 <3 <3 ")
    time.sleep(2)


def restore_mana(player, magnitude, enemy):
    
    """

        Replenishes the player's mana based
        on the specified magnitude.

    """
    
    if player.mp + magnitude >= player.maxmp:
        player.mp = player.maxmp
    else: player.mp += magnitude

    print("\n~ ~ ~ ~ ~ ~ ~ ~ ~ ")
    print("      + %d MP" % magnitude)
    print("  Mana: %d" % player.mp)
    print("~ ~ ~ ~ ~ ~ ~ ~ ~  ")
    time.sleep(2)


def use_potion(player, enemy):

    """

        Displays the player's restoration
        potions and prompts them to choose one.

    """

    possible_potions = player.restoration_potions
    potion_options = restoration_potions_dict(possible_potions)

    potions_list = []
    for potion in possible_potions:
        potions_list.append(potion.name)

    item_display(0,"",40,player,potion_options, potions_list)

    abbreviations = []
    for item in possible_potions:
        if item.abbrev not in abbreviations:
            abbreviations.append(item.abbrev)

    print("\nAbbreviations:\n")
    for abbreviation in abbreviations:
        print("     " + abbreviation)

    choice = ""
    print("\nChoose a potion or (b)ack.\n")
    while choice not in potion_options and choice not in abbreviations and choice not in back:
        choice = input(" > ").lower().strip()

    for item in possible_potions:
        if item.name == choice or item.abbrev == choice:
            if item.restores == 'Health':
                healing(player, item.restore_amount)
                player.restoration_potions.remove(item)
            elif item.restores == 'Mana': 
                restore_mana(player, item.restore_amount, enemy)
                player.restoration_potions.remove(item)


def cast_spell(player, enemy, spell_type):

    """

        Determines what spell the player
        will attack with.

    """

    if spell_type == "d":
        spells_known = player.damage_spells_known
        spell_options = damage_spells_dict(spells_known)
    elif spell_type == "h":
        spells_known = player.healing_spells_known
        spell_options = healing_spells_dict(spells_known)

    spells_list = []
    for spell in spells_known:
        spells_list.append(spell.name)

    item_display(0,"",40,player,spell_options,spells_list)

    abbreviations = []
    for item in spells_known:
        abbreviations.append(item.abbrev)

    print("\nAbbreviations:\n")
    for abbreviation in abbreviations:
        print("     " + abbreviation)


    choice = ""
    print("\nChoose a spell or (b)ack.\n")
    while choice not in spell_options and choice not in abbreviations and choice not in back:
        choice = input(" > ").lower().strip()
    
    print()
    spell_chosen = ""
    for item in spells_known:
        if item.name == choice or item.abbrev == choice:
            if player.mp < item.mp_cost:
                text_display("\nYou do not have enough mana to cast the " + item.name + ".\n", .04)
                time.sleep(1)
                spell_chosen = ""
            else: 
                spell_chosen = item
                player.mp -= spell_chosen.mp_cost
                if spell_type == "h":
                    healing(player,spell_chosen.heal_amount)

        else: 
            spell_chosen = ""

    return spell_chosen


def fight_image(player, enemy):

    """

        Displays the options the palyer
        is faced with during combat.

    """
    
    copy = enemy
    border_length = 19
    if len(player.name) > len(enemy.name):
        border_length += len(player.name)
        player_hp_spaces = 3
        enemy_hp_spaces = len(player.name) - len(enemy.name) + 3
    else:
        border_length += len(enemy.name)
        enemy_hp_spaces = 3
        player_hp_spaces = len(enemy.name) - len(player.name) + 3

    while player.hp != 0  and enemy.hp != 0:   
        
        os.system("cls")
        print("<3 " * (int(border_length / 3) + 1))
        print(("  %s's Health:" % enemy.name ) + (" " * enemy_hp_spaces) +  ("%d\n" % enemy.hp))
        print(("  %s's Health:" % player.name) + (" " * player_hp_spaces) +  ("%d" % player.hp))
        print(("  %s's Mana:  " % player.name) + (" " * player_hp_spaces) +  ("%d" % player.mp))
        print(("<3 " * (int(border_length / 3) + 1)) + "\n")
        time.sleep(1)

        print(" ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ^ ")
        print("<        Combat         >")
        print("< - - - - - - - - - - - >")
        print("<   (p)otion            >")
        print("<   (s)pell attack      >")
        print("<   (h)ealing spell     >")
        print("<   (w)eapon attack     >")
        print(" v v v v v v v v v v v v \n")

        fight_selection(player,enemy)
    # Make run away/flee an option?


def fight_selection(player, enemy):

    """

        Takes the player's input and runs 
        the appropriate function.

    """

    selected = ""
    fight_options = ['weapon attack','spell','s','h','heal','healing','healing spell'] + helping + weapon_key + potion_key

    while selected not in fight_options:  
        selected = input(" > ").lower().strip()

    if selected in ['h','heal','healing','healing spell']:
        if len(player.healing_spells_known) == 0:
            text_display("\nYou don't know any healing spells.",.05)
        else: cast_spell(player, enemy, "h")
        player_damage = -1
    elif selected in ['spell','s', 'spell attack']:
        player_damage = -1
        if len(player.damage_spells_known) == 0:
            text_display("\nYou don't know any attack spells.",.05)
        else:
            spell_chosen = cast_spell(player, enemy, "d")
            if spell_chosen != "":
                player_damage = magic_damage(player, enemy, spell_chosen)
    elif selected in potion_key:
        use_potion(player, enemy)
        player_damage = -1
    elif selected in weapon_key or selected == 'weapon attack':
        player_damage = melee_damage(player,enemy) 

    if player_damage >= 0 : 
        fight(player, player_damage, enemy)


def dealing_damage(attacker, damage, defender):

    """

        Deals damage and sets hp to 0 if 
        hp falls below 0.

    """

    if defender.hp < damage:
        damage = defender.hp

    defender.hp -= damage
    print("%s dealt %d damage to %s!" % (attacker.name, damage, defender.name))


def fight_won(player, enemy):

    """

        Checks if the player has won the fight
        and runs through looting.

    """
    print(enemy.name + " falls to the ground.\n")
    player.xp += enemy.experience_reward
    print("+%d xp" % enemy.experience_reward)
    print("Total xp: %d\n" % player.xp)
    time.sleep(1)
    player.xp += enemy.experience_reward
    gold_gain(enemy.gp, player)
    if "no loot" not in enemy.item_types:
        looting_options(player, enemy)


def fight(player, player_damage, enemy):
    
    """

        Simulates the fight between the 
        player and their enemy.    

    """


    if enemy.main_style == "magic":
        enemy_damage = magic_damage(enemy,player)
    else:
        enemy_damage = melee_damage(enemy,player)


    dodger = deciding(player,enemy)
    if dodger == "enemy":
            player_damage = 0
            counter = countering(enemy,player)
            if counter == "success":
                print("\n" + enemy.name + " counters your attack!")
                enemy_damage = enemy_damage * 2
            else: print("\n" + enemy.name + " dodges your attack!")
    elif dodger == "player":
        enemy_damage = 0
        counter = countering(player,enemy)
        if counter == "success":
            print("\n" + player.name + " counters the attack!")
            player_damage = player_damage * 2
        else: print("\n" + player.name + " dodges the attack!")

    dealing_damage(enemy, enemy_damage, player)
    dealing_damage(player, player_damage, enemy)
        
    enter()

    if player.mp != player.maxmp:
        mp_increase = attribute_bonus(player, player.INT)
        restore_mana(player, mp_increase, enemy)

    if player.hp == 0 and enemy.hp == 0:
        print("Some line about the player emerging triumphant even though it was a tough battle.")
        player.hp = 1
    
    if enemy.hp == 0:
        fight_won(player,enemy)

    if player.hp == 0:
        print("Oh dear, you're dead!\n")
        time.sleep(2)
        player.game_over = True
        exit()
