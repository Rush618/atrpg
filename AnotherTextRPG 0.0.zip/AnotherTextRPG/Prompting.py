#####################################
#         Another Text RPG          #
#         By: Rush Deeter           #
# In Collaboration With: Kathy Orta #



"""


This file contains the prompt function
and some of its sub-functions. The code
included is:

Functions:
    - prompt
    - player_examine
    - generic_help_menu


"""



from WorldMapFile import *
from Utility import enter,text_display,quit_game
from Movement import player_movement
from AcceptableLists import quitting,moving,quick_move,inspecting,locating,helping,inventory
from Locating import new_mapping
from Inventory import inventory_display



def prompt(player, map_type):
    
    """

        The main prompt for the game. While the 
        player is located on the world map, they
        are prompted to input a valid command. 
        Based on teh player's input, various other
        functions are called.

    """


    print("\n..........................")
    print("What would you like to do?")
    action = ''
    acceptable_actions = quitting+moving+quick_move+inspecting+locating+helping+inventory
    while action not in acceptable_actions:
        action = input(' > ').lower().strip()

    if action in quitting:
        quit_game(prompt,player)
    elif action in moving:
        player_movement('',player,action) 
    elif action in quick_move:
        action_list = action.split()
        if map_type == world_map:
            player_movement(action_list[1],player,action_list[0], player.location, map_type)
        else: player_movement(action_list[1],player,action_list[0], player.quest_location, map_type)
    elif action in inspecting:
        player_examine(player, map_type) 
    elif action in locating:
        if map_type == world_map:
            new_mapping(player.location,map_type)
        else: new_mapping(player.quest_location,map_type)
    elif action in inventory:
        inventory_display(player)
    elif action in helping:
        generic_help_menu()


def player_examine(player, map_type):
    
    """

    Displays the 'examination' text for the tile the 
    player is currently on.

    """
    
    if map_type == world_map:
        examine_text = map_type[player.location][EXAMINATION]
    else: examine_text = map_type[player.quest_location][EXAMINATION]
    text_display(examine_text,.03)


def generic_help_menu():
    
    """

        Displays the help menu for the prompt function.
        Eventually, this will show a list of valid commands
        that teh player has already discovered.

    """
    
    print(".........................................")
    print("                Help Menu                ")
    print(".........................................")
    print(" Explanation of the game and its basic   ")
    print(" controls (fighting, moving, examining,  ")
    print(" etc)")
    print(".........................................")
    enter()