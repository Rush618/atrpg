#####################################
#         Another Text RPG          #
#         By: Rush Deeter           #
# In Collaboration With: Kathy Orta #



"""

This file's contents handle the player's
looting process. The code included is:

Functions:
    - vog_image
    - vog_selection
    - vog_help_menu
    - vog_general_store
    - vog_town_hall
    - vog_inn


"""



import os
import time
from Utility import enter,text_display,quit_game
from AcceptableLists import helping,mistakes
from Civilization.Shops import shopkeep_options
from Civilization.Shopkeeps import filius_flander
from Equipment.Weapons import *



vog_text = []
with open("Civilization/VogText.txt", "r") as myfile:
    for lines in myfile:
        vog_text.append(lines)



vog_people_met = {'Filius Flander': False
    
    }


def vog_image(player):
    
    """

        Clears the window and displays the Vog menu.


    """
    
    os.system("cls")
    
    if 'vog' not in player.places_visited:
        text_display(vog_text[2],.05)
        text_display(vog_text[5],.05)
        text_display(vog_text[8],.05)
        player.places_visited.append('vog')
        print()
        enter()
        text_display("|'''''''''''''''''''''''''''''''''''|\n",.03)
        text_display("|        The Village of Vog         |\n",.05)
        text_display("|'''''''''''''''''''''''''''''''''''|\n",.03)
        text_display("|       -  General Store  -         |\n",.05)
        text_display("|         -  Town Hall  -           |\n",.05)
        text_display("|            -  Inn  -              |\n",.05)
        text_display("|           -  Leave  -             |\n",.05)
        text_display("'''''''''''''''''''''''''''''''''''''\n\n",.03)
    else: 
        print("|'''''''''''''''''''''''''''''''''''|")
        print("|        The Village of Vog         |")
        print("|'''''''''''''''''''''''''''''''''''|")
        print("|       -  General Store  -         |")
        print("|         -  Town Hall  -           |")
        print("|            -  Inn  -              |")
        print("|           -  Leave  -             |")
        print("'''''''''''''''''''''''''''''''''''''\n")

    vog_selection(player)


def vog_selection(player):
    
    """

        Prompts the player and continues when one of
        the options from the menu is entered.

    """
    
    vog_options = ['general store', 'generalstore', 'gs', 'g', 'town hall', 'townhall', 'th', 't', 'inn', 'i', 'exit', 'e', 'leave', 'l', 'secret', 's', 'quit', 'q'] + helping
    selected = ""
    while selected not in vog_options:  
        selected = input(" > ").lower().strip()
    if selected in ['general store','generalstore', 'gs', 'g']:
        vog_general_store(player)                                        
    elif selected in ['town hall','townhall', 'th', 't']:
        vog_town_hall(player)
    elif selected in  ['inn','i']:
        vog_inn(player)    
    elif selected in helping:
        vog_help_menu(player)
    elif selected in ['exit', 'e', 'leave', 'l']:
        text_display("You leave The Village of Vog.", .03)
        player.location = 'H9'
        time.sleep(1)
        os.system("cls")
    elif selected in ['secret', 's']:
        vog_secret_happens(player)
    elif selected in ['quit', 'q']:
        quit_game(vog_image,player)


def vog_help_menu(player):
    
    """

        Displays the Help menu for the Village of Vog.
        This help menu will explain to the player how 
        they move around town and 

    """
    
    print(".........................................")
    print("                Help Menu                ")
    print(".........................................")
    print(" Explanation of the game and its basic   ")
    print(" controls (fighting, moving, examining,  ")
    print(" etc)")
    print(".........................................")
    enter()
    vog_image(player)


def vog_secret_happens(player):                                                   # Definitely keep this and have something cool in each city, maybe all the secrets connect?
    text_display("Keep it secret, keep it safe.",.1)
    enter()
    vog_image(player)


def vog_general_store(player):

    """

        Starts the player's interactions with the
        general store owner in Vog.

    """
    
    os.system("cls")
    if vog_people_met['Filius Flander'] == False:
        print()
        text_display(filius_flander.dialogue_options['greeting'],.05)
        print('\n\n')
        vog_people_met['Filius Flander'] = True

    shopkeep_options(player, filius_flander)
    vog_image(player)


def vog_town_hall(player):
    print("The Hown's Tall")
    enter()
    vog_image(player)


def vog_inn(player):
    print("Inn like Flynn")
    enter()
    vog_image(player)