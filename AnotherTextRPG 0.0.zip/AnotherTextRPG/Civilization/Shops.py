#####################################
#         Another Text RPG          #
#         By: Rush Deeter           #
# In Collaboration With: Kathy Orta #



"""

This file's contents handle the interface
for shopkeepers. When the player asks to
see their wares, these functions are called:

Functions:
    - shopkeep_options
    - buying_options
    - selling options
    - shopkeep_item_display
    - dialogue options


"""



import os
import time
from random import randint
from Equipment.Weapons import weapons_dict
from Equipment.Armor import armor_dict
from Equipment.Potions import restoration_potions_dict
from Utility import enter,text_display
from Looting import rolling_items,item_display
from AcceptableLists import mistakes, back, armor_key, weapon_key, potion_key



def shopkeep_options(player, shopkeep):

    """

        Displays the options when at a shopkeep.

    """

    print("What would you like to do?\n")
    print("     buy    (b)")
    print("     sell   (s)")
    print("     talk   (t)")
    print("     leave  (l)\n")


    choice = ''
    acceptable_options = ["buy", "b","sell","s","talk","t","leave","l"]
    while choice not in acceptable_options:
        choice = input(" > ")

    print()
    if choice == "leave" or choice ==  "l": pass
    elif choice == "buy" or choice == "b":
        buying_options(player,shopkeep)
    elif choice == "sell" or choice == "s":
        selling_options(player,shopkeep)
    elif choice == "talk" or choice ==  "t":
        dialogue_options(player,shopkeep)


def buying_options(player, shopkeep):

    """

        Displays the buying options for the given shopkeep.

    """

    acceptable_options = [] 

    print("\nWhat would you like to buy?\n")

    if "weapons" in shopkeep.item_types:
        print("     weapons  (w)")
        for word in weapon_key:
            acceptable_options.append(word)
    
    if "armor" in shopkeep.item_types:
        print("     armor    (a)")
        for word in armor_key:
            acceptable_options.append(word)

    if "potions" in shopkeep.item_types:
        print("     potions  (p)")
        for word in potion_key:
            acceptable_options.append(word)

    print("     back     (b)\n")
    for word in back:
        acceptable_options.append(word) 
    
    choice = ''
    while choice not in acceptable_options:
        choice = input(" > ").lower().strip()

    if choice in back:
        shopkeep_options(player, shopkeep)
    elif choice in armor_key:
        shopkeep_item_display(1, "armor", player, shopkeep.weapons, int(len(shopkeep.weapons)/2), shopkeep)
    elif choice in weapon_key:
        shopkeep_item_display(1, "weapons", player, shopkeep.weapons, int(len(shopkeep.weapons)/2), shopkeep)
    elif choice in potion_key:
        shopkeep_item_display(1, "potions", player, shopkeep.potions, int(len(shopkeep.potions)/2), shopkeep)


def selling_options(player, shopkeep):

    """

        Displays the selling options for the given player.

    """

    acceptable_selling_options = []

    print("\nWhat would you like to sell?\n")

    if len(player.armors) > 0:
        print("     armor     (a)")
        for option in armor_key:
            acceptable_selling_options.append(option)

    if len(player.weapons) > 0:
        print("     weapons   (w)")
        for option in weapon_key:
            acceptable_selling_options.append(option)

    if len(player.restoration_potions) > 0:
        print("     potions   (p)")
        for option in potion_key:
            acceptable_selling_options.append(option)

    print("     back      (b)\n")
    for word in back:
        acceptable_selling_options.append(word)

    choice = ''
    while choice not in acceptable_selling_options:
        choice = input(" > ").lower().strip()

    if choice in back:
        shopkeep_options(player, shopkeep)
    elif choice in armor_key:
        shopkeep_item_display(0, "armor", player, player.armors, len(player.armors), shopkeep)
    elif choice in weapon_key:
        shopkeep_item_display(0, "weapons", player, player.weapons, len(player.weapons), shopkeep)
    elif choice in potion_key:
        shopkeep_item_display(0, "potions", player, player.restoration_potions, len(player.restoration_potions), shopkeep)
                             

def shopkeep_item_display(buying, item_type, player, possible_items, number_items_desired, shopkeep):

    """

        Displays the items a shop is buying or selling.

    """

    if buying == 1:
        items_for_sale = rolling_items(possible_items, number_items_desired)
    else: 
        items_for_sale = possible_items

    if item_type == "weapons":
        items = weapons_dict(items_for_sale)
    elif item_type == "armor":
        items = armor_dict(items_for_sale)
    elif item_type == "potions":
        items = restoration_potions_dict(items_for_sale)

    abbreviations = []
    for item in items_for_sale:
        abbreviations.append(item.abbrev)

    choice = ''
    while choice not in back and len(items_for_sale) > 0:
        os.system("cls")
        if buying == 1:
            print("                 BUYING")
        else:
            print("                 SELLING")

        if item_type == "weapons":
            items = weapons_dict(items_for_sale)
        elif item_type == "armor":
            items = armor_dict(items_for_sale)
        elif item_type == "potions":
            items = restoration_potions_dict(items_for_sale)

        items_list = []
        for item in items_for_sale:
            items_list.append(item.name)

        item_display(1,item_type,40,player,items,items_list)

        print("\nAbbreviations:\n")
        for abbreviation in abbreviations:
            print("     " + abbreviation)

        if buying == 1:
            print("\nInput an item you would like to purchase, or type 'back'.")
        elif buying == 0:
            print("\nInput an item you would like to sell, or type 'back'.")

        print("Current Gold: %d \n" % player.gp)

        choice = ''
        while choice not in back and choice not in items and choice not in abbreviations:      
            choice = input(" > ").lower().strip()

        if choice in back: pass
        elif buying == 1: 
            for item in items_for_sale:
                    if item.name == choice or item.abbrev == choice:
                        if player.gp < item.value:
                            print("\nYou do not have enough gold to buy the " + choice + ".\n")
                            time.sleep(2)
                        else: 
                            print("\nYou hand over %d gold for the %s." % (item.value,item.name))
                            print("  -%d GP" % item.value)
                            if item_type == "weapons":
                                player.weapons.append(item)
                            elif item_type == "armor":
                                player.armors.append(item)
                            player.gp -= item.value
                            items_for_sale.remove(item)
                            items.pop(item.name)
                            abbreviations.remove(item.abbrev)
                            time.sleep(2)
        elif buying == 0:
            for item in items_for_sale:
                    if item.name == choice or item.abbrev == choice:
                            print("\nYou hand over the %s for %d gold." % (item.name,item.value))
                            print("  +%d GP" % item.value)
                            items_for_sale.remove(item)
                            player.gp += item.value
                            items.pop(item.name)
                            abbreviations.remove(item.abbrev)
                            time.sleep(2)

    if buying == 1:  buying_options(player, shopkeep)
    else:  selling_options(player,shopkeep)


def dialogue_options(player, shopkeep):

    """

        Displays the dialogue options
        for a specified npc and prompts
        the player for input about what
        they would like to learn.

    """
    choice = ''
    while choice not in back:
        print("What would you like to talk about?\n")

        acceptable_options = [] + back
        for option in shopkeep.dialogue_options:
            print("     " + option)
            acceptable_options.append(option.lower())
        print("     back (b)\n")

        choice = ''
        while choice not in acceptable_options:
            choice = input(" > ")

        if choice in back: pass
        else:
            print()
            text_display(shopkeep.dialogue_options[choice], .05)
            print()
            enter()

    shopkeep_options(player,shopkeep)



