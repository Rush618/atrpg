#####################################
#         Another Text RPG          #
#         By: Rush Deeter           #
# In Collaboration With: Kathy Orta #
#   Started work on Sept 9, 2020    #



"""


This file contains the information for
the weapons in the game.

Classes:
    - Adjective
    - Material
    - Weapon_Type
    - Weapon


"""


import random
from statistics import mean



# Inside monster class a function is defined which allows for random weapon & armor generation based on a given list which is one of the attributes

class Adjective:

    """

        Lays out the setup for adjectives which are used to 
        describe weapons. The attributes are the name of the
        adjective, the multipliers that effect the minimum
        and maximum damage for the weapon, and the multiplier
        which effects how much the weapon costs.

    """

    def __init__(self, name, min_multiplier, max_multiplier, value_multiplier):
        self.name = name
        self.min_multiplier = min_multiplier
        self.max_multiplier = max_multiplier
        self.value_multiplier = value_multiplier


horrible = Adjective('horrible ', .4, .5, .15)
bad = Adjective('bad ', .5, .6, .25)
shoddy = Adjective('shoddy ', .6, .7, .5)
dull = Adjective('dull ', .8, .9, .75)
standard = Adjective('', 1, 1, 1)
sharp = Adjective('sharp ', 1.1, 1.2, 1.25)
exquisite = Adjective('exquisite ', 1.3, 1.4, 1.5)
magnificent = Adjective('magnificent ', 1.5, 1.6, 2)
godly = Adjective('godly ', 2, 2, 5)


class Material:

    """

        Initializes the name of the material for a weapon,
        the base minimum and maximum that material possesses,
        and how much that material is worth.

    """

    def __init__(self, name, base_min, base_max, base_value):
        self.name = name
        self.base_min = base_min
        self.base_max = base_max
        self.base_value = base_value


iron = Material("iron ", 2, 5, 10)
steel = Material('steel ', 4, 8, 15)
silver = Material('silver ', 7, 12, 25)
adamantine = Material('adamantine ', 11, 17, 40)


class Weapon_Type:

    """

       Sets up the different types of weapons including their
       name, minimum damage multiplier, maximum damage multiplier,
       and value multiplier, which effects the monetary value
       of a weapon.

    """

    def __init__(self, name, min_multiplier, max_multiplier, value_multiplier):
        self.name = name
        self.min_multiplier = min_multiplier
        self.max_multiplier = max_multiplier
        self.value_multiplier = value_multiplier


dagger = Weapon_Type('dagger', 1.1, .9, .8)
short_sword = Weapon_Type("short sword", .9, 1.05, 1)
longsword = Weapon_Type('longsword', .75, 1.15, 1.1)


class Weapon:

    """
    
        Uses the information from the Adjective, Material,
        and Weapon_Type classes to determine the weapon's 
        name, minimum damage, maximum damage, and value.

    """

    def __init__(self, adjective, material, weapon_type):
        self.adjective = adjective
        self.material = material
        self.weapon_type = weapon_type
        self.name = adjective.name + material.name + weapon_type.name
        self.min_dmg = round(mean([adjective.min_multiplier, weapon_type.min_multiplier]) * material.base_min)
        self.max_dmg = round(mean([adjective.max_multiplier, weapon_type.max_multiplier]) * material.base_max)
        self.value = int(((adjective.value_multiplier + weapon_type.value_multiplier) / 2) * material.base_value)




###############     Swords     ###############

sharp_iron_ss = Weapon(sharp, iron, short_sword)
standard_iron_ss = Weapon(standard, iron, short_sword)
dull_iron_ss = Weapon(dull, iron, short_sword)



###############      Axes      ###############





#############       Hammers      #############





#############      Polearms      #############





#############       Special      #############





adjectives = [dull, standard, sharp, exquisite, godly]
materials = [iron, steel, silver, adamantine]
w_types = [dagger, short_sword, longsword]

"""
weapon_list = []

for a in adjectives:
   for m in materials:
        for wt in w_types:
            new_weapon = Weapon(a, m, wt)
            weapon_list.append(new_weapon.name)

print(len(weapon_list))
"""


#adj = adjectives[random.randint(0, len(adjectives)-1)]
#print(adj.name)

#mat = materials[random.randint(0, len(materials)-1)]
#print(mat.name)



orc_weapon = Weapon(adjectives[random.randint(0, len(adjectives)-1)], materials[random.randint(0, len(materials)-1)], w_types[random.randint(0, len(w_types)-1)])
print(orc_weapon.name)
print(orc_weapon.min_dmg)
print(orc_weapon.max_dmg)