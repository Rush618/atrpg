#####################################
#         Another Text RPG          #
#         By: Rush Deeter           #
# In Collaboration With: Kathy Orta #



"""


This file lays out the villages, towns
and cities in the game.

Functions:
    - town_locator


"""



from .VillageOfVog import vog_image



def town_locator(player):
    
    """

        Checks the player's location, if there's a town
        associated with it then that town function is started.

    """
    
    if player.location == 'I9':
        vog_image(player) 



