#####################################
#         Another Text RPG          #
#         By: Rush Deeter           #
# In Collaboration With: Kathy Orta #



"""

This file's contents handle the interface
for shopkeepers. When the player asks to
see their wares, these functions are called:

Classes:
    - Shopkeep



"""



from Equipment.Weapons import *
from Equipment.Armor import *
from Equipment.Potions import *



class Shopkeep:
    def __init__(self, name, item_types, weapons, armor, potions, other, dialogue_options):
        self.name = name

        self.item_types = item_types
        self.weapons = weapons
        self.armor = armor
        self.potions = potions
        self.other = other

        self.dialogue_options = dialogue_options


filius_item_types = ["weapons", "potions"]
filius_weapons = [dull_iron_ss, standard_iron_ss, fine_iron_ss, standard_iron_baxe, dull_silver_ss]
filius_armor = []
filius_potions = [wimpy_healing_potion, wimpy_healing_potion]
filius_other = []
filius_dialogue = {"greeting": "'Hello, I'm Filius Flander, world renowned juggler!'\n'Would you care to see my wares?'",
                   "story": "'I once juggled seven knives all at once! That's how I lost this finger.' Filius points to\n where his right ring finger used to be."
    
}


filius_flander = Shopkeep("Filius Flander",filius_item_types,filius_weapons,filius_armor,filius_potions,filius_other,filius_dialogue)


